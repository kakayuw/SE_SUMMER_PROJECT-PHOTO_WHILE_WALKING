package Utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.sourcey.materiallogindemo.R;

import java.util.ArrayList;
import java.util.List;

import Model.Friend;

/**
 * Created by liujinxu on 17/7/3.
 */

public class FriendAdapter extends BaseAdapter {
    private String url = null;
    private ArrayList<Friend> friends = new ArrayList<Friend>() {
    };
    private Context context;
    public void setFriends(ArrayList friends) {
        this.friends = friends;
    }
    @Override
    public int getCount() {
        return friends.size();
    }
    public void setContext(Context context) {
        this.context = context;
    }

    @Override
    public Object getItem(int i) {
        if(friends!=null && friends.size()>i) {return friends.get(0);}
        else{return null;}
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        View view = View.inflate(context, R.layout.adapter_layout, null);
        Friend friend = friends.get(i);
        ImageView iv_picture=(ImageView) view.findViewById(R.id.iv_picture);
        TextView tv_nickname=(TextView) view.findViewById(R.id.tv_nickname);
        Bitmap bmp = null;
        try {
            bmp = BitmapFactory.decodeFile(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        iv_picture.setImageBitmap(bmp);
        tv_nickname.setText(friend.getNickname());
        return null;
    }
}
