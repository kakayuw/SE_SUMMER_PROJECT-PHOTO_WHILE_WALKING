package com.sourcey.materiallogindemo;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import Model.User;
import Utils.FriendAdapter;
import Utils.OkManager;
import butterknife.Bind;
import butterknife.ButterKnife;
import Model.Friend;

/**
 * Created by liujinxu on 17/7/3.
 */

public class FindAllActivity extends AppCompatActivity {
    private static final String TAG = "FindAllActivity";
    public static String ip="192.168.1.165:8080/bzbp/rest/json";
    private OkManager manager;

    private FriendAdapter friendAdapter;
    public static ArrayList<Friend> result = new ArrayList<Friend>();
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_findall);
//        ImageView imageView = (ImageView) findViewById(R.id.aaa);
//        Bitmap bmp = null;
//        try {
//            bmp = getImage("/aaa");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        imageView.setImageBitmap(bmp);
        new Thread(new Runnable(){
            @Override
            public void run() {
                sendHttpPost(ip);
            }}).start();

    }
    public void sendHttpPost(String getUrl) {
//        manager = new OkManager();
//        result = manager.getFriends(getUrl);
        Friend friend1 = new Friend(),friend2 = new Friend();
        friend1.setNickname("q");
        friend1.setUid(0);
        result.add(friend1);
        friend2.setUid(1);
        friend2.setNickname("a");
        result.add(friend2);
        friendAdapter = new FriendAdapter();
        friendAdapter.setContext(this);
        friendAdapter.setFriends(result);
        ListView lv_view = (ListView)findViewById(R.id.lv_view);
        lv_view.setAdapter(friendAdapter);
        lv_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Friend friend = (Friend)friendAdapter.getItem(i);
                Toast.makeText(FindAllActivity.this,friend.getNickname(),Toast.LENGTH_LONG).show();
            }
        });
    }
//    public static Bitmap getImage(String path) throws Exception{
//        URL url = new URL(path);
//        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//        InputStream is = conn.getInputStream();
//        return BitmapFactory.decodeStream(is);
//    }

}

