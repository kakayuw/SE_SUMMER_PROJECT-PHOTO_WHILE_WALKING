package utils;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by liujinxu on 17/6/30.
 */

public class OkManager<T> {
    private OkHttpClient client;
    private Handler handler;
    static final String TAG = "okmanagerActicity:";

    private static final MediaType JSON = MediaType.parse("application/json;charset=utf-8");
    private static final MediaType MEDIA_TYPE_MARKDOWN = MediaType.parse("text/x-markdown;charset=utf-8");

    public OkManager() {
        client = new OkHttpClient();
        handler = new Handler(Looper.getMainLooper());

    }

    /**
     * 向服务器提交String请求
     *
     * @param url
     * @param content
     */
    public String sendStringByPost(String url, String content) {
        Request request = new Request.Builder()
                .url(url)
                .post(RequestBody.create(JSON, content))
                .build();
        try {
            Response response = client.newCall(request).execute();
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
            return response.body().string();
        } catch (IOException e) {
            e.printStackTrace();
            return "internal error";
        }
    }

    public List<T> getAll(String url, Class<T> E){
        List<T> lists = new ArrayList<T>();
        Request request = new Request.Builder()
                .url(url)
                .get()
                .build();
        try {
            Response response = client.newCall(request).execute();
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
            String str = response.body().string();
            JsonParser parser = new JsonParser();
            JsonArray jsonArray = parser.parse(str).getAsJsonArray();
            Gson gson = new Gson();
            for(JsonElement jsonElement : jsonArray) {
                Log.v(TAG, jsonElement.toString());
                T item = gson.fromJson(jsonElement, E);
                lists.add(item);
            }
            return lists;
        } catch (IOException e) {
            e.printStackTrace();
            return  lists;
        }
    }
}
