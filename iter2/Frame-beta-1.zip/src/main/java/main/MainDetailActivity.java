package main;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import com.photowalking.R;

import java.util.ArrayList;
import java.util.List;

import utils.BitmapUtil;
import utils.UrlPath;

public class MainDetailActivity extends AppCompatActivity {

    private ListView listView;
    private static final String FILE_PATH = Environment.getExternalStorageDirectory().toString()+ UrlPath.appPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_show_detail);

        listView = (ListView) findViewById(R.id.main_detail_photo_list);
        PhotoAdapter photoAdapter = new PhotoAdapter();
        photoAdapter.addItem("2017-07-13  10:28:47.jpg");
        listView.setAdapter(photoAdapter);

    }

    public int dip2px(float dpValue) {
        final float scale = getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    private class PhotoAdapter extends BaseAdapter{
        private List<String> photos = new ArrayList<>();

        public void addItem(String str){
            photos.add(str);
        }

        @Override
        public int getCount() {
            return photos.size();
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public Object getItem(int position) {
            return photos.get(position);
        }

        @Override
        public View getView(final int position, View convertView, final ViewGroup parent) {
            if(convertView==null)
                convertView = LayoutInflater.from(MainDetailActivity.this).inflate(R.layout.main_detail_photo, null);
            final ImageView img = (ImageView)convertView.findViewById(R.id.main_detail_picture);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Bitmap bmp = BitmapUtil.decodeSampledBitmapFromFd(FILE_PATH+photos.get(position), dip2px(75), dip2px(50));
                    img.setImageBitmap(bmp);
                }
            }).start();
            return convertView;
        }
    }
}


