package com.sourcey.materiallogindemo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import Model.User;

/**
 * Created by liujinxu on 17/7/6.
 */

public class ShowUserInfoActivity extends AppCompatActivity {
    String ip="http://192.168.1.165:8080/bzbp/rest/friend/getPicture/";
    Bitmap bmp = null;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_userinfo);
        Intent intent=getIntent();
        Gson gson = new Gson();
        String jsonstr = intent.getStringExtra("jsonstr");
        final User user = gson.fromJson(jsonstr, User.class);
        final ImageView photo = (ImageView) findViewById(R.id.photo_show);
        final TextView uid = (TextView) findViewById(R.id.uid_show);
        TextView username = (TextView) findViewById(R.id.username_show);
        TextView phone = (TextView) findViewById(R.id.phone_show);
        TextView email = (TextView) findViewById(R.id.email_show);

        photo.setImageURI(Uri.parse("/"));
        uid.setText(Integer.toString(user.getId()));
        username.setText(user.getUsername());
        phone.setText(user.getPhone());
        email.setText(user.getEmail());

        new Thread(new Runnable(){
            @Override
            public void run() {
                showPhoto(user, photo);
            }}).start();
    }

    public void showPhoto(User user, ImageView photo) {
        try {
            URL url = new URL(ip+user.getId());
            Log.v("userid: ", ip+user.getId());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            bmp = BitmapFactory.decodeStream(is);
            is.close();
            photo.setImageBitmap(bmp);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
