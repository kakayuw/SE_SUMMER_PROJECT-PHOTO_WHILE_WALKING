package com.photowalking.friends;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.photowalking.R;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import com.photowalking.model.User;
import com.photowalking.utils.ProfileNetUtil;
import com.photowalking.utils.UrlPath;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by liujinxu on 17/7/6.
 */

public class ShowUserInfoActivity extends Activity {

    @Bind(R.id.tab_fri_show_img)
    ImageView img;
    @Bind(R.id.tab_fri_show_uid)
    TextView tv_uid;
    @Bind(R.id.tab_fri_show_name)
    TextView tv_name;
    @Bind(R.id.tab_fri_show_email)
    TextView tv_email;
    @Bind(R.id.tab_fri_show_add)
    LinearLayout add;

    @Bind(R.id.tab_fri_show_fri)
    LinearLayout fri;
    @Bind(R.id.tab_fri_show_delete)
    LinearLayout delete;
    @Bind(R.id.tab_fri_show_chat)
    LinearLayout chat;

    private String me;
    private User user;
    private String msg;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.friend_show);
        ButterKnife.bind(this);

        Intent intent = getIntent();
        Gson gson = new Gson();
        me = intent.getStringExtra("me");
        String jsonstr = intent.getStringExtra("jsonstr");
        user = gson.fromJson(jsonstr, User.class);

        checkfri();

        showPhoto();

        tv_uid.setText(Integer.toString(user.getId()));
        tv_name.setText(user.getUsername());
        tv_email.setText(user.getEmail());


        add.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowUserInfoActivity.this, AddFriendActivity.class);
                intent.putExtra("me", me);
                intent.putExtra("fid", Integer.toString(user.getId()));
                startActivityForResult(intent, 1);
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        if (delete(Integer.toString(user.getId()), me).equals("success")) {
                            msg = "删除成功！";
                        } else
                            msg = "删除失败！";
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getBaseContext(), msg, Toast.LENGTH_SHORT).show();
                            }
                        });
                        finish();
                    }
                }).start();
            }
        });

        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"under building",Toast.LENGTH_SHORT).show();
                //TODO START ACTIVITY CHAT WITH FRIEND
//                Intent intent = new Intent(ShowUserInfoActivity.this,ChatActivity.class);
//                startActivity(intent);
//                finish();
            }
        });

    }

    public void checkfri(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                ProfileNetUtil profileNetUtil = new ProfileNetUtil();
                String flag = profileNetUtil.sendFriendRequest(
                        Integer.toString(user.getId()),me,UrlPath.checkFriUrl);
                if (flag.equals("true")) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            add.setVisibility(View.GONE);
                            fri.setVisibility(View.VISIBLE);
                        }
                    });
                }
            }
        }).start();
    }

    public String delete(String fid, String me){
        ProfileNetUtil profileNetUtil = new ProfileNetUtil();
        String res = profileNetUtil.sendFriendRequest(fid,me,UrlPath.deleteFriUrl);
        return res;
    }

    public void showPhoto() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(UrlPath.getPicUrl+user.getId());
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    InputStream is = conn.getInputStream();
                    final Bitmap bmp = BitmapFactory.decodeStream(is);
                    is.close();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            img.setImageBitmap(bmp);
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
