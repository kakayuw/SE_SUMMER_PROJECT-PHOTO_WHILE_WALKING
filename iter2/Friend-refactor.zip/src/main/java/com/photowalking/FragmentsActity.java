package com.photowalking;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.photowalking.fragment.FriendFragment;
import com.photowalking.fragment.MainFragment;
import com.photowalking.fragment.MineFragment;
import com.photowalking.fragment.ShareFragment;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;

import java.io.File;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;

/**
 * Created by lionel on 2017/7/10.
 */

public class FragmentsActity extends Activity implements View.OnClickListener {

    /* Four ImageButtons at bottom */
    private ImageButton mainTabImgBtn;
    private ImageButton friendTabImgBtn;
    private ImageButton shareTabImgBtn;
    private ImageButton mineTabImgBtn;

    /* Four Framgments at center */
    private MainFragment mainFragment;
    private FriendFragment friendFragment;
    private ShareFragment shareFragment;
    private MineFragment mineFragment;

    private static String uid;
    private static String uname;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.tabs_layout);
        init();
        uid = getIntent().getStringExtra("me");
        uname = getIntent().getStringExtra("uname");
        checkPerssion();
        setSelect(0);
    }

    private void init(){
        mainTabImgBtn = (ImageButton) findViewById(R.id.main_tab_img);
        friendTabImgBtn = (ImageButton) findViewById(R.id.friend_tab_img);
        shareTabImgBtn = (ImageButton) findViewById(R.id.share_tab_img);
        mineTabImgBtn = (ImageButton) findViewById(R.id.mine_tab_img);

        mainTabImgBtn.setOnClickListener(this);
        friendTabImgBtn.setOnClickListener(this);
        shareTabImgBtn.setOnClickListener(this);
        mineTabImgBtn.setOnClickListener(this);
    }

    private void checkPerssion(){
        if(Build.VERSION.SDK_INT>=23){
            int READ = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
            int WRITE = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
            if(READ != PERMISSION_GRANTED || WRITE != PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this,new String[]{READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE},456);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==456){
            if(grantResults[0]!=PERMISSION_GRANTED || grantResults[1]!=PERMISSION_GRANTED) {
                Toast.makeText(getApplicationContext(),"无法访问文件及照片",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.main_tab_img:
                setSelect(0);
                break;
            case R.id.friend_tab_img:
                setSelect(1);
                break;
            case R.id.share_tab_img:
                setSelect(2);
                break;
            case R.id.mine_tab_img:
                setSelect(3);
                break;
            default: break;
        }
    }

    private void setSelect(int idx){
        FragmentManager fm = getFragmentManager();
        FragmentTransaction fragmentTransaction = fm.beginTransaction();

        resetImgBtn();
        hideFragment(fragmentTransaction);
        switch (idx){
            case 0:
                if (mainFragment == null){
                    mainFragment = MainFragment.getInstance(uid, uname);
                    fragmentTransaction.add(R.id.tab_content,mainFragment);
                }else{
                    fragmentTransaction.show(mainFragment);

                }
                fragmentTransaction.commit();
                mainTabImgBtn.setImageResource(R.drawable.homepage2);

                break;
            case 1:
                if (friendFragment==null){
                    friendFragment = FriendFragment.getInstace(uid);
                    fragmentTransaction.add(R.id.tab_content,friendFragment);
                    ListView listView = (ListView) findViewById(R.id.friend_tab_list);
                }else{
                    fragmentTransaction.show(friendFragment);
                }

                fragmentTransaction.commit();
                friendTabImgBtn.setImageResource(R.drawable.friends2);


                break;
            case 2:
                if (shareFragment==null){
                    shareFragment = ShareFragment.getInstance(uid);
                    fragmentTransaction.add(R.id.tab_content,shareFragment);
                }else{
                    fragmentTransaction.show(shareFragment);
                }
                fragmentTransaction.commit();
                shareTabImgBtn.setImageResource(R.drawable.sharedcircle2);
                break;
            case 3:
                if (mineFragment==null){
                    mineFragment = MineFragment.getInstance(uid);
                    fragmentTransaction.add(R.id.tab_content,mineFragment);
                }else{
                    fragmentTransaction.show(mineFragment);
                }
                fragmentTransaction.commit();
                mineTabImgBtn.setImageResource(R.drawable.me2);
                break;
            default: break;
        }
    }

    private void hideFragment(FragmentTransaction fragmentTransaction) {
        if (mainFragment!=null){
            fragmentTransaction.hide(mainFragment);
        }
        if (friendFragment!=null){
            fragmentTransaction.hide(friendFragment);
        }
        if (shareFragment!=null){
            fragmentTransaction.hide(shareFragment);
        }
        if (mineFragment!=null){
            fragmentTransaction.hide(mineFragment);
        }
    }

    private void resetImgBtn() {
        mainTabImgBtn.setImageResource(R.drawable.homepage);
        friendTabImgBtn.setImageResource(R.drawable.friends);
        shareTabImgBtn.setImageResource(R.drawable.sharedcircle);
        mineTabImgBtn.setImageResource(R.drawable.me);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        File parent = new File(UrlPath.downloadPath);
        File[] folders = parent.listFiles();
        if(folders.length > 0){
            for(File folder:folders){
                File[] files = folder.listFiles();
                if(files.length>0){
                    for(File file : files)
                        file.delete();
                }
                folder.delete();
            }
        }
    }
}
