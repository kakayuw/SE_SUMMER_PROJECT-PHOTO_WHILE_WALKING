package com.photowalking.main;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;
import com.photowalking.R;
import com.photowalking.model.ShareItem;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;

import java.io.File;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by liujinxu on 17/7/18.
 */

public class EditTextActivity extends AppCompatActivity {

    String TAG = "EditTextActivity";

    @Bind(R.id.text_share)
    EditText _text;
    @Bind(R.id.send)
    Button _send;
    boolean flag = true;
    String str = "";

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.main_share_text);
        ButterKnife.bind(this);
        Intent intent=getIntent();
        final String me = intent.getStringExtra("me");
        final String tid = intent.getStringExtra("tid");
        Gson gson = new Gson();
        String sItem = intent.getStringExtra("sItem");
        final ShareItem shareItem = gson.fromJson(sItem,ShareItem.class);

        _send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String text = _text.getText().toString();
                if(text.length()>140 || text=="") {
                    Toast.makeText(getBaseContext(), "字数在0-140之间", Toast.LENGTH_LONG).show();
                } else {
                    new Thread(new Runnable(){
                        @Override
                        public void run() {
                            OkManager okManager = new OkManager();
//                            shareItem.setPoem(text);
                            //TODO SEND TEXT
//                            str = okManager.sendText(shareItem, me);
                            File file = new File(UrlPath.uploadTmpPath+"/"+tid+".zip");
                            Log.e("upload file: ",file.getAbsolutePath());
                            Log.e(">>>>>>>>>>","upload started.....");
                            okManager.uploadFile(UrlPath.uploadUrl+tid, file);
                            Log.e("<<<<<<<<<<","upload ended.....");
                            file.delete();
                            flag = false;
                        }}).start();
                    if (str.equals("success")) {
                        finish();
                    }
                }
            }
        });

    }
}