package com.photowalking.fragment;

import android.app.Fragment;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.photowalking.R;

import java.util.List;

import com.photowalking.adapter.ShareAdapter;
import com.photowalking.model.ShareItem;
import com.photowalking.share.ViewOthersDetailActivity;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;
import com.photowalking.viewUtils.XListView;

/**
 * Created by lionel on 2017/7/10.
 */

public class ContFragment extends Fragment implements XListView.XListViewListener{

    private View view;

    private String uid;

    public static ContFragment getInstance(int res, String uid){
        ContFragment fragment = new ContFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("res", res);
        bundle.putString("me",uid);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        int res = getArguments().getInt("res");
        view = inflater.inflate(res, container, false);
        String[] params = new String[2];
        uid = getArguments().getString("me");
        switch(res){
            case R.layout.share_fri:
                params[0] = UrlPath.getShareFriUrl;
                params[1] = String.valueOf(R.id.fri_share_list);
                new LoadShareTask().execute(params);
                break;
            case R.layout.share_all:
                params[0] = UrlPath.getShareAllUrl;
                params[1] = String.valueOf(R.id.all_share_list);
                new LoadShareTask().execute(params);
                break;
            case R.layout.share_mine:
                params[0] = UrlPath.getShareMineUrl;
                params[1] = String.valueOf(R.id.my_share_list);
                new LoadShareTask().execute(params);
                break;
            default: break;
        }
        return view;
    }



    public class LoadShareTask extends AsyncTask<String, Void, List<ShareItem>> {
        private int listId;

        @Override
        protected List<ShareItem> doInBackground(String... params) {
            if (params.length == 0) {
                return null;
            }
            String url = params[0];
            listId = Integer.parseInt(params[1]);
            OkManager manager = new OkManager<>();
            while (!OkManager.checkNetwork(ContFragment.this.getActivity().getApplicationContext())){
                Toast.makeText(ContFragment.this.getActivity().getApplicationContext(),"未连接网络",Toast.LENGTH_SHORT);
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            List<ShareItem> shares= manager.getAll(url, ShareItem.class);
            return shares;
        }

        @Override
        protected void onPostExecute(List<ShareItem> shareItems) {
            if(shareItems != null){
                final ShareAdapter shareAdapter = new ShareAdapter(ContFragment.this.getActivity(), UrlPath.getPicUrl,
                        R.layout.shareitem_layout);
                for(ShareItem s : shareItems){
                    shareAdapter.addItem(s);
                }
                ListView listView = (ListView) view.findViewById(listId);
                listView.setAdapter(shareAdapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String sid = shareAdapter.getItem(position).getSid();
                        sid = "11313";
                        Intent intent = new Intent(getActivity(), ViewOthersDetailActivity.class);
                        intent.putExtra("sid",sid);
                        intent.putExtra("me",uid);
                        startActivityForResult(intent, 1);
                    }
                });
            }
        }
    }

    @Override
    public void onRefresh() {
        System.out.println("asfd");
    }

    @Override
    public void onLoadMore() {
        System.out.println("asfd");
    }
}
