package com.photowalking.fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.photowalking.FragmentsActity;
import com.photowalking.R;

import java.io.IOException;
import java.util.List;

import com.photowalking.adapter.FriendAdapter;
import com.photowalking.model.Friend;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;

/**
 * Created by lionel on 2017/7/11.
 */

public class FriendFragment extends Fragment{

    private View view;
    private SwipeRefreshLayout srl;

    private String uid;

    public static FriendFragment getInstace(String uid){
        FriendFragment friendFragment = new FriendFragment();
        Bundle bundle = new Bundle();
        bundle.putString("me",uid);
        friendFragment.setArguments(bundle);
        return friendFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.tab_friend, container, false);
        srl = (SwipeRefreshLayout)view.findViewById(R.id.friend_tab_refreshlayout);
        srl.setColorSchemeColors(Color.BLUE);
        srl.setDistanceToTriggerSync(50); //设置手指下拉多少距离开始下拉刷新
        srl.setProgressBackgroundColorSchemeColor(Color.WHITE);  //设置下拉圆圈背景颜色
        srl.setProgressViewOffset(true,10,240);
        srl.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        srl.setRefreshing(false); //刷新完成隐藏进度条
                    }
                },4000);
            }
        }); //设置下拉刷新监听事件

        uid = getArguments().getString("me");
        new LoadFriendTask().execute();
        return view;
    }

    public class LoadFriendTask extends AsyncTask<Void, Void, List<Friend>>{

        @Override
        protected List<Friend> doInBackground(Void... params) {
            while (!OkManager.checkNetwork(FriendFragment.this.getActivity().getApplicationContext())){
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            OkManager manager = new OkManager<>();
            List<Friend> friends = null;
            friends = manager.getAll(UrlPath.getFriUrl+uid, Friend.class);
            return friends;
        }

        @Override
        protected void onPostExecute(List<Friend> friends) {
            if (friends != null) {
                FriendAdapter adapter = null;
                try {
                    adapter = new FriendAdapter(FriendFragment.this.getActivity(), UrlPath.getPicUrl);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                for (Friend f : friends) {
                    adapter.addItem(f);
                }
                ListView flist = (ListView) view.findViewById(R.id.friend_tab_list);
                flist.setAdapter(adapter);
            }
        }
    }

}
