package com.photowalking.utils;

import android.os.Environment;

/**
 * Created by lionel on 2017/7/7.
 */

public class UrlPath {
    public static String ip = "http://192.168.1.165:8080/bzbp/rest";

    static final String STORAGE_PATH = Environment.getExternalStorageDirectory().toString();
    public static String APP_PATH = STORAGE_PATH+"/bzbp";
    public static String uploadTmpPath = APP_PATH+"/tmp/utmp";
    public static String downloadPath = APP_PATH+"/tmp/dtmp";
    public static String dataPath = APP_PATH+"/data";
    public static String tracePath = dataPath+"/trace/";
    public static String userPath = APP_PATH+"/user";

    /* user urls */
    public static String loginUrl = ip+"/user/login";
    public static String signupUrl = ip+"/user/signup";
    public static String getPicUrl = ip+"/user/getPicture/";
    public static String getUserByNameUrl = ip+"/user/getUserByUsername/";
    public static String getUserByUidUrl = ip+"/user/getUserByUid/";

    /* friend urls */
    public static String getFriUrl = ip+"/friend/getAll/";
    public static String addFriUrl = ip+"/friend/addFriend/";
    public static String deleteFriUrl = ip+"/friend/deleteFriend/";

    /* share urls */
    public static String getShareFriUrl = ip+"/share/friendGetAll/";
    public static String getShareAllUrl = ip+"/share/getAll";
    public static String getShareMineUrl = ip+"/share/myGetAll/";
    public static String uploadUrl = ip+"/share/addPicFile/";
    public static String uploadSitemUrl = ip+"/share/addShare";
    public static String downloadUrl = ip+"/share/getPicFile/";

    /* profile urls */
    public static String updateUserUrl = ip + "/user/updateUser";
    public static String chgUserPwd = ip + "/user/changePassword";


}
