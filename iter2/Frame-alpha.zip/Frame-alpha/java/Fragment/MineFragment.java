package Fragment;

import android.app.Fragment;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;

import com.sourcey.materiallogindemo.LoginActivity;
import com.sourcey.materiallogindemo.R;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import Profile.ProfileAboutActivity;
import Profile.ProfileChargeActivity;
import Profile.ProfileEditActivity;
import Profile.ProfilePwdActivity;
import Utils.UrlPath;
import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by lionel on 2017/7/11.
 */

public class MineFragment extends Fragment{
    private View view;

    @Bind(R.id.tab_me_about_bzbp)
    Button _about;
    @Bind(R.id.tab_me_edit_info)
    Button _edit;
    @Bind(R.id.tab_me_charge)
    Button _charge;
    @Bind(R.id.tab_me_log_out)
    Button _logout;
    @Bind(R.id.tab_me_modify_pwd)
    Button _pwd;
    Bitmap bmp = null;
    boolean bitmapFlag = false;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.tab_me, container, false);
        doThings();
        return view;
    }

    public void doThings() {
        Intent intent = getActivity().getIntent();
        final String me = intent.getStringExtra("me");

        ButterKnife.bind(getActivity());

        final ImageView photo = (ImageView) view.findViewById(R.id.photo);
        photo.setImageURI(Uri.parse("/"));
        new Thread(new Runnable(){
            @Override
            public void run() {
                showPhoto(me, photo);
            }}).start();
        while(!bitmapFlag);
        photo.setImageBitmap(bmp);
        bitmapFlag = false;

        _about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ProfileAboutActivity.class);
                intent.putExtra("me",me);
                startActivityForResult(intent, 1);
            }
        });
        _charge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ProfileChargeActivity.class);
                intent.putExtra("me",me);
                startActivityForResult(intent, 1);
            }
        });
        _pwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ProfilePwdActivity.class);
                intent.putExtra("me",me);
                startActivityForResult(intent, 1);
            }
        });
        _edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),  ProfileEditActivity.class);
                intent.putExtra("me",me);
                startActivityForResult(intent, 1);
            }
        });
        _logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivityForResult(intent, 1);
            }
        });
    }


    public void showPhoto(String me, ImageView photo) {
        try {
            URL url = new URL(UrlPath.getPicUrl+me);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            bmp = BitmapFactory.decodeStream(is);
            bitmapFlag = true;
            is.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
