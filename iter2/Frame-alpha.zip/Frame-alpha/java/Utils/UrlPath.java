package Utils;

/**
 * Created by lionel on 2017/7/7.
 */

public class UrlPath {
    public static String ip = "http://192.168.1.165:8080/bzbp/rest";

    public static String getFriUrl = ip+"/friend/getAll/1";

    public static String getPicUrl = ip+"//user/getPicture/";

    /* friend urls */
    public static String addFriUnameUrl = ip+"/user/getUserByUsername/";

    public static String addFriUidUrl = ip+"/user/getUserByUid/";

    public static String applyFriUrl = ip+"/friend/addFriend/";

    public static String deleteFriUrl = ip+"/friend/deleteFriend/";

    /* share urls */
    public static String getShareFriUrl = ip+"/share/friendGetAll/1";

    public static String getShareAllUrl = ip+"/share/getAll";

    public static String getShareMineUrl = ip+"/share/myGetAll/1";

    /* profile urls */
    public static String updateUserUrl = ip + "/user/updateUser";

    public static String chgUserPwd = ip + "/user/changePassword";


}
