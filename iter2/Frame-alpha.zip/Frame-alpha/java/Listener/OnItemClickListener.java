package Listener;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import com.sourcey.materiallogindemo.FindAllActivity;
import com.sourcey.materiallogindemo.ShowUserInfoActivity;

import Model.User;


/**
 * Created by liujinxu on 17/7/6.
 */

class MyOnItemClickListener implements AdapterView.OnItemClickListener, View.OnClickListener {

    private static Context applicationContext;

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position,
                            long id) {

        User user = (User) parent.getItemAtPosition(position);

        Toast.makeText(getApplicationContext(), user.getUsername(), Toast.LENGTH_SHORT).show();


    }

    public Context getApplicationContext() {
        return applicationContext;
    }

    @Override
    public void onClick(View v) {
        Log.v("asfasf", v.toString());

    }
}