package Adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.sourcey.materiallogindemo.R;

import java.util.ArrayList;
import java.util.List;

import Model.Friend;

/**
 * Created by liujinxu on 17/7/3.
 */


public class FriendAdapter extends BaseAdapter {

    private static final int TYPE_ITEM = 0;
    private static final int TYPE_SEPARATOR = 1;
    private static final int TYPE_MAX_COUNT = TYPE_SEPARATOR + 1;
    private ArrayList<Friend> friends = new ArrayList<Friend>();
    private LayoutInflater inflater;
    private TreeSet<Integer> set = new TreeSet<Integer>();
    private String ip;

    public FriendAdapter(Context context, String ip) throws IOException {
        inflater = LayoutInflater.from(context);
        this.ip = ip;
    }

    public void addItem(Friend friend) {
        friends.add(friend);
    }

    public void addSeparatorItem(Friend friend) {
        friends.add(friend);
        set.add(friends.size() - 1);
    }

    public int getItemViewType(int position) {
        return set.contains(position) ? TYPE_SEPARATOR : TYPE_ITEM;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_MAX_COUNT;
    }

    @Override
    public int getCount() {
        return friends.size();
    }

    @Override
    public Object getItem(int position) {
        return friends.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.adapter_layout, null);
            holder.textView = (TextView) convertView.findViewById(R.id.share_item_text);
            holder.imageView = (ImageView) convertView.findViewById(R.id.share_item_picture);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.textView.setText(friends.get(position).getNickname());
        holder.picUrl = ip+friends.get(position).getUid();
        new setImageTask().execute(holder);
        return convertView;
    }

    public static byte[] getBytes(InputStream is) throws IOException {
        ByteArrayOutputStream outstream = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int len = -1;
        while ((len = is.read(buffer)) != -1) {
            outstream.write(buffer, 0, len);
        }
        outstream.close();
        return outstream.toByteArray();
    }

    public static class ViewHolder {
        public ImageView imageView;
        public TextView textView;
        public String picUrl;
    }

    public class setImageTask extends AsyncTask<ViewHolder, Void, Bitmap>{

        private ViewHolder vholder;
        @Override
        protected Bitmap doInBackground(ViewHolder... params) {
            if(params.length == 0 || params==null)
                return null;
            vholder = params[0];
            String picUrl = params[0].picUrl;
            Bitmap bmp = null;
            try {
                URL url = new URL(picUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                InputStream is = conn.getInputStream();
                bmp = BitmapFactory.decodeStream(is);
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return bmp;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            vholder.imageView.setImageBitmap(bitmap);
        }
    }
}
