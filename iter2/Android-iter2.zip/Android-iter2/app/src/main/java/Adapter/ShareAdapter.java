package Adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.sourcey.materiallogindemo.R;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.TreeSet;

import Model.ShareItem;

/**
 * Created by lionel on 2017/7/7.
 */

public class ShareAdapter extends BaseAdapter {

    private static final int TYPE_ITEM = 0;
    private static final int TYPE_SEPARATOR = 1;
    private static final int TYPE_MAX_COUNT = TYPE_SEPARATOR + 1;
    private ArrayList<ShareItem> shares = new ArrayList<ShareItem>();
    private LayoutInflater inflater;
    private TreeSet<Integer> set = new TreeSet<Integer>();
    private String ip;
    private int layout;
    private ViewHolder holder;

    public ShareAdapter(Context context, String ip, int layout) {
        inflater = LayoutInflater.from(context);
        this.ip = ip;
        this.layout = layout;

    }

    public void addItem(ShareItem shareItem){
        shares.add(shareItem);
    }

    public int getItemViewType(int position) {
        return set.contains(position) ? TYPE_SEPARATOR : TYPE_ITEM;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_MAX_COUNT;
    }

    @Override
    public int getCount() {
        return shares.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(layout, null);
            holder.textView = (TextView) convertView.findViewById(R.id.share_item_text);
            holder.imageView = (ImageView) convertView.findViewById(R.id.share_item_picture);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.textView.setText(shares.get(position).getTitle());
        holder.picUrl = ip+shares.get(position).getUid();
        new setImageTask().execute(holder);
        return convertView;
    }

    public static class ViewHolder {
        public ImageView imageView;
        public TextView textView;
        public String picUrl;
    }

    public class setImageTask extends AsyncTask<ShareAdapter.ViewHolder, Void, Bitmap> {

        private ShareAdapter.ViewHolder vholder;
        @Override
        protected Bitmap doInBackground(ShareAdapter.ViewHolder... params) {
            if(params.length == 0 || params==null)
                return null;
            vholder = params[0];
            String picUrl = params[0].picUrl;
            Bitmap bmp = null;
            try {
                URL url = new URL(picUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                InputStream is = conn.getInputStream();
                bmp = BitmapFactory.decodeStream(is);
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return bmp;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            vholder.imageView.setImageBitmap(bitmap);
        }
    }
}
