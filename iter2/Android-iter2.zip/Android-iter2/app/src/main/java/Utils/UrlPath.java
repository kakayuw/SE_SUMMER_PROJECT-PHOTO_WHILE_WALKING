package Utils;

/**
 * Created by lionel on 2017/7/7.
 */

public class UrlPath {
    public static String ip = "http://192.168.1.165:8080/bzbp/rest";

    /* user urls */
    public static String loginUrl = ip+"/user/login";
    public static String signupUrl = ip+"/user/signup";
    public static String getPicUrl = ip+"/user/getPicture/";
    public static String getUserByNameUrl = ip+"/user/getUserByUsername/";
    public static String getUserByUidUrl = ip+"/user/getUserByUid/";

    /* friend urls */
    public static String getFriUrl = ip+"/friend/getAll/1";
    public static String addFriUrl = ip+"/friend/addFriend/";
    public static String deleteFriUrl = ip+"/friend/deleteFriend/";

    /* share urls */
    public static String getShareFriUrl = ip+"/share/friendGetAll/1";
    public static String getShareAllUrl = ip+"/share/getAll";
    public static String getShareMineUrl = ip+"/share/myGetAll/1";

    /* profile urls */
    public static String updateUserUrl = ip + "/user/updateUser";
    public static String chgUserPwd = ip + "/user/changePassword";

    /* routine urls */
    public static String findRouteList = "/";
    public static String findRoute = "/";


}
