package Fragment;

import android.app.Fragment;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.google.gson.Gson;
import com.sourcey.materiallogindemo.FragmentsActivity;
import com.sourcey.materiallogindemo.R;
import com.sourcey.materiallogindemo.SignupActivity;

import java.io.IOException;
import java.util.List;

import Adapter.FriendAdapter;
import Friends.AddFriendActivity;
import Friends.ShowUserInfoActivity;
import Model.Friend;
import Model.User;
import Utils.OkManager;
import Utils.ProfileNetUtil;
import Utils.UrlPath;
import butterknife.Bind;
import butterknife.ButterKnife;

import static com.sourcey.materiallogindemo.R.drawable.me;

/**
 * Created by lionel on 2017/7/11.
 */

public class FriendFragment extends Fragment{

    private View view;
    boolean f = false;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.tab_friend, container, false);
        new LoadFriendTask().execute(UrlPath.getFriUrl);
        ImageButton _addButton = (ImageButton) view.findViewById(R.id.add_friend);
        _addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the Signup activity
                Intent intent = new Intent(getActivity(), AddFriendActivity.class);
                intent.putExtra("me",((FragmentsActivity)getActivity()).getMyuid());
                startActivityForResult(intent, 1);
            }
        });
        return view;
    }

    public class LoadFriendTask extends AsyncTask<String, Void, List<Friend>>{

        @Override
        protected List<Friend> doInBackground(String... params) {
            if (params.length == 0) {
                return null;
            }
            String friUrl = params[0];
            OkManager manager = new OkManager<Friend>();
            List<Friend> friends= manager.getAll(friUrl, Friend.class);
            return friends;
        }

        @Override
        protected void onPostExecute(List<Friend> friends) {
            if (friends != null) {
                FriendAdapter adapter = null;
                try {
                    adapter = new FriendAdapter(FriendFragment.this.getActivity(), UrlPath.getPicUrl);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                for (Friend f : friends) {
                    adapter.addItem(f);
                }
                ListView flist = (ListView) view.findViewById(R.id.friend_tab_list);
                flist.setAdapter(adapter);
                flist.setOnItemClickListener(new MyOnItemClickListener());
            }
        }
    }

    private class MyOnItemClickListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                                long id) {

            final Friend friend = (Friend) parent.getItemAtPosition(position);
            final Intent intent = new Intent(FriendFragment.this.getActivity(), ShowUserInfoActivity.class);
            new Thread(new Runnable(){
                @Override
                public void run() {
                    User user = getUser(friend);
                    Gson gson = new Gson();
                    String jsonstr = gson.toJson(user);
                    intent.putExtra("jsonstr",jsonstr);
                    intent.putExtra("me",1);
                    f = true;
                }}).start();
            while(!f);
            startActivityForResult(intent, 1);
        }

        public User getUser(Friend friend) {
            User user = new User();
            ProfileNetUtil profileNetUtil = new ProfileNetUtil();
            //OkManager okManager = new OkManager();
            user = profileNetUtil.getUserByUid(UrlPath.getUserByUidUrl+String.valueOf(friend.getUid()), String.valueOf(friend.getUid()));
            return user;
        }
    }

}
