package Model;

/**
 * Created by liujinxu on 17/7/11.
 */

public class SendBytes {
    private String pic;
    private int uid;
    private String picname;

    public String getPic(){
        return this.pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public int getUid(){
        return this.uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getPicname() {
        return this.picname;
    }

    public void setPicname(String picname) {
        this.picname = picname;
    }

    public byte[] getBytePic(){
        return this.pic.getBytes();
    }
}
