package Utils;

/**
 * Created by liujinxu on 17/7/7.
 */

public class UrlPath {
    public String addFriendUrl = "http://192.168.1.165:8080/bzbp/rest/friend/addFriend/";
    //{fid}/{uid}
    public String deleteFriendUrl = "http://192.168.1.165:8080/bzbp/rest/friend/deleteFriend/";
    //{fid}/{uid}
    public String blockFriendUrl = "/";
    //{fid}/{uid}
    public String modifyNicknameUrl = "/";

    public String getAllFriendUrl = "http://192.168.1.165:8080/bzbp/rest/friend/getAll/";

    public String loginUrl = "http://192.168.1.165:8080/bzbp/rest/user";

    public String signupUrl = "http://192.168.1.165:8080/bzbp/rest";

    public String searchUserUrl = "http://192.168.1.165:8080/bzbp/rest/user/getUserByUsername/";

    public String getPictureUrl = "http://192.168.1.165:8080/bzbp/rest/user/getPicture/";

    public String getUserByUsername = "http://192.168.1.165:8080/bzbp/rest/user/getUserByUsername/";

    public String getUserByUid = "http://192.168.1.165:8080/bzbp/rest/user/getUserByUid/";

}
