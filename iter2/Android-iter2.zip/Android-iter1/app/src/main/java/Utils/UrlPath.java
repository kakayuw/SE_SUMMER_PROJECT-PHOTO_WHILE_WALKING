package Utils;

/**
 * Created by liujinxu on 17/7/7.
 */

public class UrlPath {
    public String addFriendUrl = "http://192.168.1.165:8080/bzbp/rest/friend/addFriend/";
    //{fid}/{uid}
    public String deleteFriendUrl = "/";
    //{fid}/{uid}
    public String blockFriendUrl = "/";
    //{fid}/{uid}
    public String modifyNicknameUrl = "/";

    public String getAllFriendUrl = "http://192.168.1.165:8080/bzbp/rest/friend/getAll/";

    public String loginUrl = "192.168.1.165:8080/bzbp/rest/user";

    public String signupUrl = "192.168.1.165:8080/bzbp/rest";

    public String searchUserUrl = "192.168.1.165:8080/bzbp/rest/user/getUserByUsername/";

    public String getPictureUrl = "http://192.168.1.165:8080/bzbp/rest/user/getPicture/";

}
