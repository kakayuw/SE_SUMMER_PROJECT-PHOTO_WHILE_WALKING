package com.sourcey.materiallogindemo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by liujinxu on 17/7/10.
 */


public class ShowProfileActivity extends AppCompatActivity {

    @Bind(R.id.about_bzbp)
    Button _about;
    @Bind(R.id.edit)
    Button _edit;
    @Bind(R.id.charge)
    Button _charge;
    @Bind(R.id.log_out)
    Button _logout;
    @Bind(R.id.modify_pwd)
    Button _pwd;
    Bitmap bmp = null;
    String ip ="http://192.168.1.165:8080/bzbp/rest/user/getPicture/";
    boolean bitmapFlag = false;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_profile);
        Intent intent = getIntent();
        final String me = intent.getStringExtra("me");

        ButterKnife.bind(this);

        final ImageView photo = (ImageView) findViewById(R.id.photo);
        photo.setImageURI(Uri.parse("/"));
        new Thread(new Runnable(){
            @Override
            public void run() {
                showPhoto(me, photo);
            }}).start();
        while(!bitmapFlag);
        photo.setImageBitmap(bmp);
        bitmapFlag = false;

        _about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowProfileActivity.this,
                        ProfileAboutActivity.class);
                intent.putExtra("me",me);
                startActivityForResult(intent, 1);
            }
        });
        _charge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowProfileActivity.this,
                        ProfileChargeActivity.class);
                intent.putExtra("me",me);
                startActivityForResult(intent, 1);
            }
        });
        _pwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowProfileActivity.this,
                        ProfilePwdActivity.class);
                intent.putExtra("me",me);
                startActivityForResult(intent, 1);
            }
        });
        _edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowProfileActivity.this,
                        ProfileEditActivity.class);
                intent.putExtra("me",me);
                startActivityForResult(intent, 1);
            }
        });
        _logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShowProfileActivity.this,
                        LoginActivity.class);
                startActivityForResult(intent, 1);
            }
        });
    }
    public void showPhoto(String me, ImageView photo) {
        try {
            URL url = new URL(ip+me);
            Log.v("userid: ", ip+me);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            bmp = BitmapFactory.decodeStream(is);
            bitmapFlag = true;
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
