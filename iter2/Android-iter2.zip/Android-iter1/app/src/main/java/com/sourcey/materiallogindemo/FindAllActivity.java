package com.sourcey.materiallogindemo;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Model.User;
import Utils.FriendAdapter;
import Utils.OkManager;
import Model.Friend;

import android.view.Window;

/**
 * Created by liujinxu on 17/7/3.
 */

public class FindAllActivity extends AppCompatActivity {

    private List<Friend> friends = new ArrayList<Friend>();

    public static String getFriUrl = "http://192.168.1.165:8080/bzbp/rest/friend/getAll/1";

    static String my_uid = "";




    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_findall);
        Intent intent=getIntent();
        final String me = intent.getStringExtra("me");
        my_uid = me;
        loadFriends();

        ((ImageButton) findViewById(R.id.top_add))
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(FindAllActivity.this,
                                AddFriendActivity.class);
                        intent.putExtra("me",me);
                        startActivityForResult(intent, 1);
                    }
                });
    }

    public boolean loadFriends() {
        new FetchFriendInfo().execute(getFriUrl);
        return true;

    }

    public boolean sendHttpPost(String getUrl) {
        OkManager manager = new OkManager();
        friends.addAll(manager.getFriends(getUrl));
        return true;

    }

    public class FetchFriendInfo extends AsyncTask<String, Void, Friend[]> {

        @Override
        protected Friend[] doInBackground(String... params) {
            if (params.length == 0) {
                return null;
            }
            String friUrl = params[0];
            OkManager manager = new OkManager();
            List<Friend> friList = manager.getFriends(friUrl);
            Friend[] friends = friList.toArray(new Friend[friList.size()]);
            return friends;
        }

        @Override
        protected void onPostExecute(Friend[] friends) {
            if (friends != null) {
                FriendAdapter adapter = null;
                try {
                    adapter = new FriendAdapter(FindAllActivity.this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                for (Friend f : friends) {
                    Log.v("friend: ", ""+f.getUid());
                    adapter.addItem(f);
                }
                ListView flist = (ListView) findViewById(R.id.lv_view);
                flist.setAdapter(adapter);
                flist.setOnItemClickListener(new MyOnItemClickListener());
            }
        }

        private class MyOnItemClickListener implements AdapterView.OnItemClickListener {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {

                final Friend friend = (Friend) parent.getItemAtPosition(position);
                final Intent intent = new Intent(FindAllActivity.this,ShowUserInfoActivity.class);
                new Thread(new Runnable(){
                    @Override
                public void run() {
                        User user = getUser(friend);
                        Gson gson = new Gson();
                        String jsonstr = gson.toJson(user);
                        intent.putExtra("jsonstr",jsonstr);
                        intent.putExtra("me",my_uid);
                    }}).start();
                startActivityForResult(intent, 1);
            }
        }

        public User getUser(Friend friend) {
            User user = new User();
            OkManager okManager = new OkManager();
            user = okManager.getUserByUid("/", String.valueOf(friend.getUid()));
            return user;
        }

    }
}


