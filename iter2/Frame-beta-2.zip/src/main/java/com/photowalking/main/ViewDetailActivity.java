package com.photowalking.main;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;

import com.baidu.location.LocationClient;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.Polyline;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.map.TextureMapView;
import com.baidu.mapapi.model.LatLng;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.photowalking.R;

import android.widget.AdapterView.OnItemClickListener;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.photowalking.adapter.PhotoAdapter;
import com.photowalking.model.PhotoInfo;
import com.photowalking.model.TraceInfo;
import com.photowalking.utils.FileUtil;
import com.photowalking.utils.UrlPath;
import com.photowalking.viewUtils.HorizontalListView;

public class ViewDetailActivity extends AppCompatActivity {

    private static final String TAG = "ViewDetailActivity";
    private TraceInfo ti = new TraceInfo();
    private PhotoInfo pi = new PhotoInfo();

    private TextureMapView mMapView;
    private BaiduMap mBaiduMap;
    private Polyline mVirtureRoad;

    public LocationClient mLocationClient = null;
    private BitmapDescriptor bdA;
    private BitmapDescriptor bdB;

    private OverlayOptions polylineOptions;
    private List<LatLng> polylines = new ArrayList<LatLng>();

    private FileUtil fu = new FileUtil();
    private String id = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SDKInitializer.initialize(getApplicationContext());
        setContentView(R.layout.main_show_detail);
        Intent intent1 = this.getIntent();
        String date = intent1.getStringExtra("date");
        String time = intent1.getStringExtra("time");
//        id = intent1.getStringExtra("id");
        mMapView = (TextureMapView) findViewById(R.id.bmapView);
        mMapView.onCreate(this, savedInstanceState);
        mBaiduMap = mMapView.getMap();
        bdA = BitmapDescriptorFactory.fromResource(R.drawable.huaji);
        bdB = BitmapDescriptorFactory.fromResource(R.drawable.arrow_down);
        loadTrace(date, time);
        loadMarker();
        new LoadPictureTask().execute();
    }

    private void loadMarker() {
    };

    private void loadTrace(String date, String time) {
        polylines = null;           //empty the polylines
        String polyStr = fu.fileToJson(date + "/" + time);
        Gson gson = new Gson();
        List<LatLng> loadPoly = gson.fromJson(polyStr ,new TypeToken<List<LatLng>>() {}.getType());
        polylines = loadPoly;
        polylineOptions = new PolylineOptions().points(polylines).width(4).color(Color.DKGRAY);
        mVirtureRoad = (Polyline) mBaiduMap.addOverlay(polylineOptions);
        String infoStr = fu.fileToJson(date + "/info_" + time);
        ti = gson.fromJson(infoStr, TraceInfo.class);
        if (polylines != null) {
            turnToLocation(polylines.get(0));
        }
    }
    private void turnToLocation(LatLng llA) {
        MapStatus mMapStatus = new MapStatus.Builder()
                .target(llA)
                .zoom(19)
                .build();
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(mMapStatus));
    }

    private class LoadPictureTask extends AsyncTask<String, Void, List<String>> {
        @Override
        protected List<String> doInBackground(String... params) {
            if (params.length == 0) {
                return null;
            }
            List<String> photos = null;
            try {
                photos = getPicturesFromTI();
            } catch (ParseException e) {
                e.printStackTrace();
            }
            //  List<String> photos = getPictures(UrlPath.APP_PATH,".jpg");
            return photos;
        }

        @Override
        protected void onPostExecute(List<String> photos) {
            if (photos != null) {
                final PhotoAdapter adapter = new PhotoAdapter(ViewDetailActivity.this);
                for (String s : photos) {
                    adapter.addItem(s);
                }
                HorizontalListView flist = (HorizontalListView) findViewById(R.id.main_detail_photo_list);
                flist.setAdapter(adapter);
                flist.setOnItemClickListener(new OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String photoFileName = adapter.getItem(position);
                        LatLng llA = getPositionFromPI(photoFileName);
                        MarkerOptions ooA = new MarkerOptions().position(llA).icon(bdB).zIndex(9).draggable(true);
                        mBaiduMap.addOverlay(ooA);
                        turnToLocation(llA);
                    }
                });
            }
        }
    }

    private LatLng getPositionFromPI(String photoFile) {
        String date = photoFile.substring(0,10);
        String time = photoFile.substring(11,19);
        File fileList[] = new File(UrlPath.tracePath+date).listFiles();
        for ( int i = 0; i < fileList.length; i++ ) {
            String filename = fileList[i].getName();
            if ( filename.contains("p_") && filename.contains(time) ) {
                Gson gson = new Gson();
                String infoStr = fu.fileToJson(date + "/p_" + time);
                pi = gson.fromJson(infoStr, PhotoInfo.class);
                break;
            }
        }
        LatLng llA = new LatLng(pi.getLat(), pi.getLon());
        return llA;
    }

    private List<String> getPicturesFromTI() throws ParseException {
        List<String> pictureFiles = new ArrayList<String>();
        List<String> pictureInfoFiles = new ArrayList<String>();
        String path = UrlPath.tracePath + ti.getTraceDate();
        Log.e(path, path);
        File dateFolder = new File(path);
        File fileList[] = dateFolder.listFiles();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//小写的mm表示的是分钟
        Date start = sdf.parse(ti.getTraceDate() + " " + ti.getStartTime());
        Date end = sdf.parse(ti.getTraceDate() + " " + ti.getEndTime());
        for (int i = 0; i < fileList.length; i++) {
            File filei = fileList[i];

            if (filei.getName().contains(".jpg"))  {
                String timei = filei.getName().substring(0,8);
                Date time = sdf.parse(  ti.getTraceDate() + " " + timei);
                if (time.after(start) && time.before(end)) {
                    pictureFiles.add(ti.getTraceDate() + "/" + filei.getName());
                }

            }
            if (filei.getName().contains("p_"))  pictureInfoFiles.add(ti.getTraceDate() + "/" + filei.getName());
        }
        return pictureFiles;
    }


}


