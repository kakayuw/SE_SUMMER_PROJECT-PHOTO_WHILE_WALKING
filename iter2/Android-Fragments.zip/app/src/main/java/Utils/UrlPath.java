package Utils;

/**
 * Created by lionel on 2017/7/7.
 */

public class UrlPath {
    public static String ip = "http://192.168.1.165:8080/bzbp";

    public static String getFriUrl = ip+"/rest/friend/getAll/1";

    public static String getPicUrl = ip+"/rest/user/getPicture/";

    public static String getShareAllUrl = ip+"/rest/share/getAll";
}
