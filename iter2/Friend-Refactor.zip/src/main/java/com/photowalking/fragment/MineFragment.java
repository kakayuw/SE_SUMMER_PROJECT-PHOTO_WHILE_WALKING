package com.photowalking.fragment;

import android.app.Fragment;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.baidu.platform.comapi.map.F;
import com.photowalking.LoginActivity;
import com.photowalking.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import com.photowalking.profile.ProfileAboutActivity;
import com.photowalking.profile.ProfileChargeActivity;
import com.photowalking.profile.ProfileEditActivity;
import com.photowalking.profile.ProfilePwdActivity;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;

/**
 * Created by lionel on 2017/7/11.
 */

public class MineFragment extends Fragment{
    private View view;
    private ImageView photo;

    LinearLayout about_layout;
    LinearLayout edit_layout;
    LinearLayout charge_layout;
    LinearLayout logout_layout;
    LinearLayout pwd_layout;

    private String uid;

    private Handler handler;

    public static MineFragment getInstance(String uid){
        MineFragment mineFragment = new MineFragment();
        Bundle bundle = new Bundle();
        bundle.putString("me",uid);
        mineFragment.setArguments(bundle);
        return mineFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.tab_me, container, false);
        uid = getArguments().getString("me");
        handler = new Handler();
        doThings();
        return view;
    }

    public void doThings() {
        photo = (ImageView) view.findViewById(R.id.photo);
        new ShowPhotoTask().execute(uid);

        about_layout = (LinearLayout) view.findViewById(R.id.tab_me_about_bzbp);
        edit_layout = (LinearLayout) view.findViewById(R.id.tab_me_edit_info);
        charge_layout = (LinearLayout) view.findViewById(R.id.tab_me_charge);
        logout_layout = (LinearLayout) view.findViewById(R.id.tab_me_logout);
        pwd_layout = (LinearLayout) view.findViewById(R.id.tab_me_modify_pwd);

        about_layout.setFocusable(true);
        about_layout.setFocusableInTouchMode(true);
        about_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), ProfileAboutActivity.class);
                intent.putExtra("me",uid);
                startActivityForResult(intent, 1);
            }
        });

        charge_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ProfileChargeActivity.class);
                intent.putExtra("me",uid);
                startActivityForResult(intent, 1);
            }
        });

        pwd_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ProfilePwdActivity.class);
                intent.putExtra("me",uid);
                startActivityForResult(intent, 1);
            }
        });

        edit_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),  ProfileEditActivity.class);
                intent.putExtra("me",uid);
                startActivityForResult(intent, 1);

            }
        });

        logout_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivityForResult(intent, 1);
            }
        });
    }

    private class ShowPhotoTask extends AsyncTask<String, Void, Bitmap>{

        @Override
        protected Bitmap doInBackground(String... params) {
            if(params.length == 0)
                return null;
            Bitmap bmp = null;
            File folder = new File(UrlPath.userPath);
            if(!folder.exists())
                folder.mkdir();
            File user = new File(UrlPath.userPath+"/"+uid);
            if(!user.exists())
                user.mkdir();
            String path = UrlPath.userPath+"/"+uid+"/pic.jpg";
            File pic = new File(path);
            if(!pic.exists()){
                try {
                    while(!OkManager.checkNetwork(getActivity())){
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getActivity(),"未连接到网络,无法获取头像",Toast.LENGTH_SHORT).show();
                            }
                        });
                        Thread.sleep(5000);
                    }
                    OkManager okManager = new OkManager();
                    if(okManager.downloadFile(UrlPath.getPicUrl+params[0],path)!="success"){
                        return null;
                    };
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            bmp = BitmapFactory.decodeFile(path);
            return bmp;
        }

        @Override
        protected void onPostExecute(Bitmap bmp) {
            if(bmp==null){
                Toast.makeText(getActivity(),"获取头像失败",Toast.LENGTH_SHORT).show();
                return;
            }
            photo.setImageBitmap(bmp);
        }
    }
}
