package com.photowalking.share;

import android.content.Context;
import android.widget.ListView;

/**
 * Created by lionel on 2017/7/21.
 */

public class ShareHolder {
    public Context context;
    public ListView listView;
    public String url;
    public String uid;
    public int pagenum;

    public ShareHolder(Context context, ListView listView, String url, String uid){
        this.context = context;
        this.listView = listView;
        this.url = url;
        this.uid = uid;
        pagenum = 1;
    }
}
