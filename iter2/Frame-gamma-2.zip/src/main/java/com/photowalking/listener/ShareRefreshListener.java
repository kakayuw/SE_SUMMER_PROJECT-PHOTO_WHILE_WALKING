package com.photowalking.listener;

import android.os.Handler;
import android.os.Message;

import com.photowalking.adapter.ShareAdapter;
import com.photowalking.share.LoadShareTask;
import com.photowalking.share.ShareHolder;
import com.photowalking.viewUtils.PullableRelativeLayout;

/**
 * Created by lionel on 2017/7/21.
 */

public class ShareRefreshListener implements PullableRelativeLayout.OnRefreshListener {

    private ShareHolder shareHolder;

    public ShareRefreshListener(ShareHolder shareHolder){
        this.shareHolder = shareHolder;
    }

    @Override
    public void onRefresh(final PullableRelativeLayout pullableRelativeLayout)
    {
        ShareAdapter shareAdapter = (ShareAdapter) shareHolder.listView.getAdapter();
        shareAdapter.clear();
        shareHolder.pagenum=1;
        new LoadShareTask().execute(shareHolder);
        shareHolder.pagenum++;
        new Handler()
        {
            @Override
            public void handleMessage(Message msg)
            {
                // 告知控件加载完毕
                pullableRelativeLayout.refreshFinish(PullableRelativeLayout.SUCCEED);
            }
        }.sendEmptyMessageDelayed(0, 5000);
    }

    @Override
    public void onLoadMore(final PullableRelativeLayout pullableRelativeLayout)
    {
        ShareAdapter shareAdapter = (ShareAdapter) shareHolder.listView.getAdapter();
        new LoadShareTask().execute(shareHolder);
        shareHolder.pagenum++;
//        new Handler()
//        {
//            @Override
//            public void handleMessage(Message msg)
//            {
//                // 告知控件加载完毕
//                pullableRelativeLayout.loadmoreFinish(PullableRelativeLayout.SUCCEED);
//            }
//        }.sendEmptyMessageDelayed(0, 5000);
    }

}
