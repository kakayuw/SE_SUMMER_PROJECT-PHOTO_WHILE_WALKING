package com.photowalking.fragment;

import android.app.Fragment;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.photowalking.R;

import java.util.List;

import com.photowalking.adapter.ShareAdapter;
import com.photowalking.listener.ShareRefreshListener;
import com.photowalking.model.ShareItem;
import com.photowalking.share.LoadShareTask;
import com.photowalking.share.ShareHolder;
import com.photowalking.share.ViewOthersDetailActivity;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;
import com.photowalking.viewUtils.PullableRelativeLayout;

/**
 * Created by lionel on 2017/7/10.
 */

public class ContFragment extends Fragment{

    private View view;


    private PullableRelativeLayout prl;
    private ListView listView;

    private String uid;

    public static ContFragment getInstance(int res, String uid){
        ContFragment fragment = new ContFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("res", res);
        bundle.putString("me",uid);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        int res = getArguments().getInt("res");
        view = inflater.inflate(res, container, false);
        uid = getArguments().getString("me");
        switch(res){
            case R.layout.share_fri:
                listView = (ListView) view.findViewById(R.id.fri_share_list);
                ShareHolder shareFHolder = new ShareHolder(getActivity(),listView,UrlPath.getShareFriUrl+uid,uid);
                new LoadShareTask().execute(shareFHolder);
//                new LoadShareTask().execute(UrlPath.getShareFriUrl+uid);
                break;
            case R.layout.share_all:
                listView = (ListView) view.findViewById(R.id.all_share_list);
                ShareHolder shareAHolder = new ShareHolder(getActivity(),listView,UrlPath.getShareAllUrl,uid);
                new LoadShareTask().execute(shareAHolder);
                prl = (PullableRelativeLayout)view.findViewById(R.id.all_share_pullable_layout);
                prl.setOnRefreshListener(new ShareRefreshListener(shareAHolder));
//                new LoadShareTask().execute(UrlPath.getShareAllUrl);
                break;
            case R.layout.share_mine:
                listView = (ListView) view.findViewById(R.id.my_share_list);
                ShareHolder shareMHolder = new ShareHolder(getActivity(),listView,UrlPath.getShareMineUrl+uid,uid);
                new LoadShareTask().execute(shareMHolder);
//                new LoadShareTask().execute(UrlPath.getShareMineUrl+uid);
                break;
            default: break;
        }
        return view;
    }

}
