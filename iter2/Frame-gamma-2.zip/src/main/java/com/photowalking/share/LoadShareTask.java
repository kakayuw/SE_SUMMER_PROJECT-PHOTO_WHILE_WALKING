package com.photowalking.share;

import android.content.Intent;
import android.os.AsyncTask;
import android.view.View;
import android.widget.AdapterView;

import com.photowalking.R;
import com.photowalking.adapter.ShareAdapter;
import com.photowalking.model.ShareItem;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;

import java.util.List;

/**
 * Created by lionel on 2017/7/21.
 */

public class LoadShareTask extends AsyncTask<ShareHolder, Void, List<ShareItem>> {

    private ShareHolder shareHolder;

    @Override
    protected List<ShareItem> doInBackground(ShareHolder... params) {
        if (params.length == 0) {
            return null;
        }
        shareHolder = params[0];
        String url = params[0].url;
        while (!OkManager.checkNetwork(params[0].context)){
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        OkManager manager = new OkManager<>();
        List<ShareItem> shares= manager.getAll(url+"/"+shareHolder.pagenum, ShareItem.class);
        return shares;
    }

    @Override
    protected void onPostExecute(List<ShareItem> shareItems) {
        if(shareItems != null){
            final ShareAdapter shareAdapter = new ShareAdapter(shareHolder.context, UrlPath.getPicUrl,
                    R.layout.shareitem_layout);
            for(ShareItem s : shareItems){
                shareAdapter.addItem(s);
            }
            shareHolder.listView.setAdapter(shareAdapter);
            shareHolder.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String sid = shareAdapter.getItem(position).getSid();
                    Intent intent = new Intent(shareHolder.context, ViewOthersDetailActivity.class);
                    intent.putExtra("sid",sid);
                    intent.putExtra("me",shareHolder.uid);
                    shareHolder.context.startActivity(intent);
                }
            });
        }
    }
}

