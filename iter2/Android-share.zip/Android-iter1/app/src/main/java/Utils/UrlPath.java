package Utils;

/**
 * Created by 10911 on 2017/7/7.
 */

public class UrlPath {
    public static String getFriUrl = "http://192.168.1.165:8080/bzbp/rest/friend/getAll/1";

    public static String getPicUrl = "http://192.168.1.165:8080/bzbp/rest/user/getPicture/";

    public static String getShareAllUrl = "http://192.168.1.165:8080/bzbp/rest/share/getAll";
}
