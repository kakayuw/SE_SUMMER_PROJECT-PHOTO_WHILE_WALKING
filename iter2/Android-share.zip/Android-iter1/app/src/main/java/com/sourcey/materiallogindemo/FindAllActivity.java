package com.sourcey.materiallogindemo;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import Model.User;
import Utils.FriendAdapter;
import Utils.OkManager;
import Utils.UrlPath;
import butterknife.Bind;
import butterknife.ButterKnife;
import Model.Friend;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.widget.ListView;

/**
 * Created by liujinxu on 17/7/3.
 */

public class FindAllActivity extends AppCompatActivity {

    static String TAG ="findallActivity";

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_findall);
        loadFriends();
    }

    public boolean loadFriends() {
        new FetchFriendInfo().execute(UrlPath.getFriUrl);
        return true;

    }

    public class FetchFriendInfo extends AsyncTask<String, Void, List<Friend>>{

        @Override
        protected List<Friend> doInBackground(String... params) {
            if (params.length == 0) {
                return null;
            }
            String friUrl = params[0];
            OkManager manager = new OkManager<Friend>();
            List<Friend> friends= manager.getAll(friUrl, Friend.class);
            return friends;
        }

        @Override
        protected void onPostExecute(List<Friend> friends) {
            if (friends != null) {
                FriendAdapter adapter = null;
                try {
                    adapter = new FriendAdapter(FindAllActivity.this, UrlPath.getPicUrl);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                for (Friend f : friends) {
                    adapter.addItem(f);
                }
                ListView flist = (ListView) findViewById(R.id.lv_view);
                flist.setAdapter(adapter);
            }
        }
    }
}


