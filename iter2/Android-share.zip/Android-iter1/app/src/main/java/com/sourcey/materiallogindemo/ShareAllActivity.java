package com.sourcey.materiallogindemo;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.Window;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

import Model.ShareItem;
import Utils.OkManager;
import Utils.ShareAdapter;
import Utils.UrlPath;

public class ShareAllActivity extends AppCompatActivity {

    static String TAG ="ShareAllActivity";
    private TextView mTextMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_share_all);
        loadAll();
    }

    public boolean loadAll(){
        new LoadShareAllTask().execute(UrlPath.getShareAllUrl);
        return true;
    }

    public class LoadShareAllTask extends AsyncTask<String, Void, List<ShareItem>>{
        @Override
        protected List<ShareItem> doInBackground(String... params) {
            if (params.length == 0) {
                return null;
            }
            String shareUrl = params[0];
            OkManager manager = new OkManager<ShareItem>();
            List<ShareItem> shares= manager.getAll(shareUrl, ShareItem.class);
            return shares;
        }

        @Override
        protected void onPostExecute(List<ShareItem> shareItems) {
            if(shareItems != null){
                ShareAdapter shareAdapter = new ShareAdapter(ShareAllActivity.this, UrlPath.getPicUrl);
                for(ShareItem s : shareItems){
                    shareAdapter.addItem(s);
                }
                ListView listView = (ListView) findViewById(R.id.sa_view);
                listView.setAdapter(shareAdapter);
            }
        }
    }
}
