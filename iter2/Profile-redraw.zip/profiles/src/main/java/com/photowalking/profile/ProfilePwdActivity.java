package com.photowalking.profile;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.photowalking.R;

import com.photowalking.model.User;
import com.photowalking.utils.ProfileNetUtil;
import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by liujinxu on 17/7/10.
 */

public class ProfilePwdActivity extends Activity {

    @Bind(R.id.change_submit)
    Button _changeButton;
    @Bind(R.id.pwd_old)
    EditText _old;
    @Bind(R.id.pwd_new)
    EditText _new;
    @Bind(R.id.pwd_sure)
    EditText _sure;

    private String msg;
    private boolean flag;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_pwd);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        final String me = intent.getStringExtra("me");

        _changeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable(){
                    @Override
                    public void run() {
                        final String oldpwd = _old.getText().toString();
                        final String newpwd = _new.getText().toString();
                        final String sure = _sure.getText().toString();
                        if(TextUtils.isEmpty(oldpwd) || TextUtils.isEmpty(oldpwd)
                                || TextUtils.isEmpty(oldpwd)){
                            toast("请填写所有所需密码");
                            return;
                        }
                        User user = new User();
                        if(!newpwd.equals(sure)){
                            toast("两次输入的新密码不一致");
                            return;
                        }
                        user.setPassword(oldpwd);
                        user.setId(Integer.parseInt(me));
                        ProfileNetUtil profileNetUtil = new ProfileNetUtil();
                        msg = profileNetUtil.sendPwdPost(user,newpwd);
                        if(msg.equals("success")){
                            toast("更改成功");
                            finish();
                        }
                        else {
                            toast("更改失败");
                        }
                    }}).start();


            }
        });
    }

    private void toast(final String str) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public String change_pwd(String me) {
        final String oldpwd = _old.getText().toString();
        final String newpwd = _new.getText().toString();
        final String sure = _sure.getText().toString();
        User user = new User();
        if(!newpwd.equals(sure)){return "failed";}
        user.setPassword(oldpwd);
        user.setId(Integer.parseInt(me));
        ProfileNetUtil profileNetUtil = new ProfileNetUtil();
        String res = profileNetUtil.sendPwdPost(user,newpwd);
        return res;
    }
}
