package com.photowalking.profile;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.photowalking.R;

import com.photowalking.model.User;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.ProfileNetUtil;
import com.photowalking.utils.UrlPath;
import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by liujinxu on 17/7/10.
 */

public class ProfileEditActivity extends Activity {

    @Bind(R.id.edit_submit)
    Button _editButton;
    @Bind(R.id.username)
    EditText _username;
    @Bind(R.id.email)
    EditText _email;

    User user = new User();
    ProfileNetUtil profileNetUtil = new ProfileNetUtil();

    boolean getUserFlag = true;
    private String msg;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.profile_edit);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        final String me = intent.getStringExtra("me");
        if(!OkManager.checkNetwork(getApplicationContext())){
            Toast.makeText(getApplicationContext(),"未连接到网络,无法获取信息",Toast.LENGTH_SHORT).show();
        }else {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    user = profileNetUtil.getUserByUid(UrlPath.getUserByUidUrl + me, me);
                    getUserFlag = false;
                }
            }).start();
            while (getUserFlag) ;
            _username.setText(user.getUsername());
            _email.setText(user.getEmail());
        }
        _editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable(){
                    @Override
                    public void run() {
                        final String username = _username.getText().toString();
                        final String email = _email.getText().toString();
                        if(TextUtils.isEmpty(username) || TextUtils.isEmpty(email)){
                            toast("用户名/邮箱不能为空");
                            return;
                        }
                        User user = new User();
                        user.setEmail(email);
                        user.setUsername(username);
                        user.setId(Integer.parseInt(me));
                        if(!OkManager.checkNetwork(getApplicationContext())) {
                            toast("未连接到网络,无法提交");
                            return;
                        }else {
                            msg = profileNetUtil.sendEditPost(user);
                        }
                        if(msg == "success"){
                            toast("修改成功");
                            finish();
                        }
                        else {
                            toast("修改失败");
                        }
                    }}).start();

            }
        });
    }

    private void toast(final String str) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
