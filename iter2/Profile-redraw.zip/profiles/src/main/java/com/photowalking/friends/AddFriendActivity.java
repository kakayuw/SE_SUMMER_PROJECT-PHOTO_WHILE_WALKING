package com.photowalking.friends;

import android.app.Activity;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.photowalking.R;
import com.photowalking.fragment.FriendFragment;
import com.photowalking.model.Friend;
import com.photowalking.utils.ProfileNetUtil;
import com.photowalking.utils.UrlPath;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by lionel on 2017/7/29.
 */

public class AddFriendActivity extends Activity {

    @Bind(R.id.tab_fri_add_info)
    EditText et_info;
    @Bind(R.id.tab_fri_add_remark)
    EditText et_remark;
    @Bind(R.id.tab_fri_add_send)
    LinearLayout send;

    private String fid;
    private String nickname;
    private String me;

    private String msg;
    private String remark;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.friend_add);
        ButterKnife.bind(this);

        fid = getIntent().getStringExtra("fid");
        nickname = getIntent().getStringExtra("remark");
        me = getIntent().getStringExtra("me");

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String info = et_info.getText().toString();
                remark = et_info.getText().toString();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        ProfileNetUtil profileNetUtil = new ProfileNetUtil();
                        String res = profileNetUtil.sendFriendRequest(fid,me, UrlPath.addFriUrl);
                        if(res.equals("success")){
                            if(remark==null || remark.equals(""))
                                remark = nickname;
                            FriendFragment.getAdapter().addItem(new Friend(Integer.parseInt(fid),remark));
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    FriendFragment.getAdapter().notifyDataSetChanged();
                                }
                            });
                            msg = "添加成功";
                        }else{
                            msg = "添加失败";
                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getBaseContext(),msg,Toast.LENGTH_SHORT).show();
                            }
                        });
                        finish();
                    }
                }).start();
            }
        });

    }

}
