package com.photowalking.fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.photowalking.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.photowalking.adapter.MainAdapter;
import com.photowalking.main.NewTraceActivity;
import com.photowalking.main.ViewDetailActivity;
import com.photowalking.model.MainItem;
import com.photowalking.utils.FileUtil;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;
import com.photowalking.utils.ZipUtil;

/**
 * Created by lionel on 2017/7/10.
 */

public class MainFragment extends Fragment{
    private  View view;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.tab_main, container, false);
        loadItems();

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.main_tab_plus);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent intent = new Intent(getActivity(), NewTraceActivity.class);
//                intent.putExtra("me",me);
//                startActivityForResult(intent, 1);
//                startActivity(intent);
                share();
            }
        });

        return view;
    }

    void share(){
        try {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Log.e(">>>>>>>>>>>>>>","compress started.....");
                    ZipUtil.compress(UrlPath.APP_PATH+"/photo");
                    Log.e("<<<<<<<<<<<<<<","compress ended.....");
                    File file = new File(UrlPath.APP_PATH+"/photo.zip");
                    try {
                        Log.e(">>>>>>>>>>>>>>","upload started.....");
                        OkManager okManager = new OkManager();
                        okManager.uploadFile(UrlPath.uploadPicUrl, file);
                        Log.e("<<<<<<<<<<<<<<","ended.....");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    void loadItems(){
        MainAdapter mainAdapter = null;
        try {
            mainAdapter = new MainAdapter(MainFragment.this.getActivity());
            //TODO read files and create Mainitem then add to mainAdapter
            //MainItem item = new MainItem(title, stime, totime, miles, photos);
            //mainAdapter.addItem(item);
            MainItem item1 = new MainItem("haha","2017-7-8","25","330","6");
            MainItem item2 = new MainItem("ohoh","2017-8-9","22","560","12");
            mainAdapter.addItem(item1);
            mainAdapter.addItem(item2);
        } catch (IOException e) {
            e.printStackTrace();
        }
        ListView listView = (ListView) view.findViewById(R.id.main_tab_list);
        listView.setAdapter(mainAdapter);
        listView.setOnItemClickListener(new ItemClickListener());
        listView.setOnItemLongClickListener(new ItemLongClickListener());
    };

    private class ItemClickListener implements AdapterView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Intent intent = new Intent(getActivity(), ViewDetailActivity.class);
//            intent.putExtra("me",me);
            intent.putExtra("net",false);
            startActivityForResult(intent, 1);
        }
    }

    private class ItemLongClickListener implements AdapterView.OnItemLongClickListener{
        @Override
        public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
            new  AlertDialog.Builder(getActivity())
                    .setTitle("请选择" )
                    .setSingleChoiceItems(new  String[] {"选项1", "选项2", "选项3" , "选项4" },  0 ,
                            new  DialogInterface.OnClickListener() {

                                public   void  onClick(DialogInterface dialog,  int  which) {
                                    dialog.dismiss();
                                }
                            }
                    )
                    .setNegativeButton("取消" ,  null )
                    .show();
            return true;
        }
    }

}
