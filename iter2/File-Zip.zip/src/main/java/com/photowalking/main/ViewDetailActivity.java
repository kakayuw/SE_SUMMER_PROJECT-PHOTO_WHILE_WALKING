package com.photowalking.main;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;

import com.baidu.location.LocationClient;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.Polyline;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.map.TextureMapView;
import com.baidu.mapapi.model.LatLng;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.photowalking.R;

import android.widget.AdapterView.OnItemClickListener;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.photowalking.adapter.PhotoAdapter;
import com.photowalking.model.TraceInfo;
import com.photowalking.utils.FileUtil;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;
import com.photowalking.utils.ZipUtil;
import com.photowalking.viewUtils.HorizontalListView;

public class ViewDetailActivity extends AppCompatActivity {

    private static final String TAG = "ViewDetailActivity";
    private TraceInfo ti = null;

    private TextureMapView mMapView;
    private BaiduMap mBaiduMap;
    private Polyline mVirtureRoad;

    public LocationClient mLocationClient = null;
    private BitmapDescriptor bdA;

    private OverlayOptions polylineOptions;
    private List<LatLng> polylines = new ArrayList<LatLng>();

    private FileUtil fu = new FileUtil();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_show_detail);
//        Intent intent1 = this.getIntent();
//        String date = intent1.getStringExtra("date");
//        String time = intent1.getStringExtra("time");
//        mMapView = (TextureMapView) findViewById(R.id.bmapView);
//        mMapView.onCreate(this, savedInstanceState);
//        mBaiduMap = mMapView.getMap();
//        bdA = BitmapDescriptorFactory.fromResource(R.drawable.huaji);
//        loadTrace(date, time);
        Boolean flag = getIntent().getBooleanExtra("net", false);
        new LoadPictureTask().execute(flag);
    }

    private void loadTrace(String date, String time) {
        polylines = null;           //empty the polylines
        String polyStr = fu.fileToJson(date + "/" + time);
        Gson gson = new Gson();
        List<LatLng> loadPoly = gson.fromJson(polyStr ,new TypeToken<List<LatLng>>() {}.getType());
        polylines = loadPoly;
        polylineOptions = new PolylineOptions().points(polylines).width(4).color(Color.DKGRAY);
        mVirtureRoad = (Polyline) mBaiduMap.addOverlay(polylineOptions);
        String infoStr = fu.fileToJson(date + "/info_" + time);
        ti = gson.fromJson(infoStr, TraceInfo.class);
        if (polylines != null) {
            turnToLocation(polylines.get(0));
        }
    }
    private void turnToLocation(LatLng llA) {
        MapStatus mMapStatus = new MapStatus.Builder()
                .target(llA)
                .zoom(18)
                .build();
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(mMapStatus));
    }

    private class LoadPictureTask extends AsyncTask<Boolean, Void, List<String>> {

        @Override
        protected List<String> doInBackground(Boolean... params) {
            if (params.length == 0) {
                return null;
            }
            List<String> photos= new ArrayList<>();
            Boolean flag = params[0];
            if(flag){
                OkManager okManager = new OkManager();
                Date date = new Date();
                String tmpFile = UrlPath.TMP_PATH+"/"+date.toString();
                Log.e(">>>>>>>>>>>", "download started......");
                okManager.downloadFile(UrlPath.downloadPicUlr, tmpFile+".zip");
                Log.e("<<<<<<<<<<<", "download ended......");
                Log.e(">>>>>>>>>>>", "decompress started......");
                ZipUtil.decompress(tmpFile+".zip");
                Log.e("<<<<<<<<<<<", "decompress ended......");
//                List<String> lists = getPictures(tmpFile, ".jpg");
//                for(String str: lists)
//                    photos.add(str);
                for(int i=0;i<60;++i){
                    //TODO implements read picture
                    photos.add(UrlPath.APP_PATH+"/a.jpg");
                    photos.add(UrlPath.APP_PATH+"/b.jpg");
                }
            }else{
                for(int i=0;i<60;++i){
                    //TODO implements read picture
                    photos.add(UrlPath.APP_PATH+"/a.jpg");
                    photos.add(UrlPath.APP_PATH+"/b.jpg");
                }
            }
            return photos;
        }

        int depth = 0;
        String path = null;
        List<String> list_all = new ArrayList<String>();

        private List<String> getPictures(final String strPath, String format) {
            List<String> list_last = new ArrayList<String>();
            File file = new File(strPath);
            List<String> list = printDirectory(file, depth);
            list.size();
            /**
             * 在循环判断之前，就必须完成树的遍历
             */
            for (int k = 0; k < list.size(); k++) {

                int idx = list.get(k).lastIndexOf(".");
                Log.v("idx:", String.valueOf(idx));
                if (idx <= 0) {
                    continue;
                }
                String suffix = list.get(k).substring(idx);
            /*
             * format可以是".jpg"、".jpeg"等等，例如suffix.toLowerCase().equals(".jpeg")
             */
                if (suffix.toLowerCase(Locale.PRC).equals(format)
                        ) {
                    list_last.add(list.get(k));
                }
            }
            /**
             * 如果没有这个，因为List<String> list_all = new
             * ArrayList<String>();作为GetEachDir类构造函数的成员变量
             * ，可以不被清楚，再再次使用GetEachDir的printDirectory,之前的list_all依然存在
             */
            list_all.clear();
            return list_last;
        }

        private List<String> printDirectory(File f, int depth) {
            if (!f.isDirectory()) {
                // 如果不是目录，则打印输出
                Log.i("1", "I am not Dir");
            } else {
                File[] fs = f.listFiles();
                depth++;
                for (int i = 0; i < fs.length; ++i) {
                    File file = fs[i];
                    path = file.getPath();
                    list_all.add(path);
                    printDirectory(file, depth);
                }
            }
            return list_all;
        }

        @Override
        protected void onPostExecute(List<String> photos) {
            if (photos != null) {
                final PhotoAdapter adapter = new PhotoAdapter(ViewDetailActivity.this);
                for (String s : photos) {
                    adapter.addItem(s);
                }
                HorizontalListView flist = (HorizontalListView) findViewById(R.id.main_detail_photo_list);
                flist.setAdapter(adapter);
                flist.setOnItemClickListener(new OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        //TODO implement onitemclick
                    }
                });
            }
        }
    }

}


