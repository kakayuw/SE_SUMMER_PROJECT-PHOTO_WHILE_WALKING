package action;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import dao.UserDao;
import model.User;
import service.UserpicService;

public class UserAction extends BaseAction {

	private int uid;
	private String username;
	private String password;
	private String email;
	private String phone;
	private UserDao userDao;

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	/* userpic service */
	private UserpicService userpicService;

	public void setUserpicService(UserpicService userpicService) {
		this.userpicService = userpicService;
	}

	private File pic;

	public void setPic(File pic) {
		this.pic = pic;
	}

	// method
	public String get() {
		return "success";
	}

	public String getAll() {
		List<User> users = userDao.getAllUsers();
		request().setAttribute("user", users);
		return "success";
	}

	public String signup() {
		if (pic != null)
			userpicService.save(1, pic);
		else {
			System.out.println("asdfasdf");
		}
		return "test";
	}

	public void pic() throws IOException {
		int uid = -1;
		HttpServletRequest request = ServletActionContext.getRequest();
		if (!"".equals(request.getParameter("uid")) && request.getParameter("uid") != null) {
			uid = Integer.parseInt(request.getParameter("uid"));
		}
		if (uid == -1)
			return;
		System.out.println(uid);
		byte[] pic = userpicService.getPicById(uid);
		HttpServletResponse response = ServletActionContext.getResponse();
		OutputStream outputStream = response.getOutputStream();
		response.setCharacterEncoding("utf-8");
		response.setContentType("application/octet-stream");
		response.addHeader("Content-Disposition", "attachment; filename=\"acc.png\"");
		outputStream.write(pic);
		outputStream.flush();
		outputStream.close();
	}

}
