package com.sourcey.materiallogindemo;

import android.app.Activity;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import Model.User;

/**
 * Created by liujinxu on 17/7/6.
 */

public class ShowUserInfoActivity extends AppCompatActivity {
    User user = (User) getIntent().getSerializableExtra("user_found");

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_userinfo);
        ImageView photo = (ImageView) findViewById(R.id.photo_show);
        TextView uid = (TextView) findViewById(R.id.uid_show);
        TextView username = (TextView) findViewById(R.id.username_show);
        TextView phone = (TextView) findViewById(R.id.phone_show);
        TextView email = (TextView) findViewById(R.id.email_show);

        //photo.setImageURI(Uri.parse("/"));
        uid.setText(user.getId());
        username.setText(user.getUsername());
        phone.setText(user.getPhone());
        email.setText(user.getEmail());

    }
}
