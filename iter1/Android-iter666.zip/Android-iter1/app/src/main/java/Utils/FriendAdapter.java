package Utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.TreeSet;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.sourcey.materiallogindemo.R;

import java.util.ArrayList;
import java.util.List;

import Model.Friend;

/**
 * Created by liujinxu on 17/7/3.
 */

public class FriendAdapter extends BaseAdapter {
//    private String url = null;
//    private List<Friend> friends = new ArrayList<Friend>() {
//    };
//    private Context context;
//    public void setFriends(List friends) {
//        this.friends.addAll(friends);
//    }
//    @Override
//    public int getCount() {
//        return friends.size();
//    }
//    public void setContext(Context context) {
//        this.context = context;
//    }
//
//    @Override
//    public Object getItem(int i) {
//        if(friends!=null && friends.size()>i) {return friends.get(0);}
//        else{return null;}
//    }
//
//    @Override
//    public long getItemId(int i) {
//        return i;
//    }
//
//    @Override
//    public View getView(int i, View convertView, ViewGroup viewGroup) {
//        View view = View.inflate(context, R.layout.adapter_layout, null);
//        Friend friend = friends.get(i);
//        ImageView iv_picture=(ImageView) view.findViewById(R.id.iv_picture);
//        TextView tv_nickname=(TextView) view.findViewById(R.id.tv_nickname);
//        Bitmap bmp = null;
//        try {
//            bmp = BitmapFactory.decodeFile(url);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        iv_picture.setImageBitmap(bmp);
//        tv_nickname.setText(friend.getNickname());
//        return null;
//    }
private static final int TYPE_ITEM = 0;
    private static final int TYPE_SEPARATOR = 1;
    private static final int TYPE_MAX_COUNT = TYPE_SEPARATOR + 1;
    private ArrayList<Friend> friends = new ArrayList<Friend>();
    private LayoutInflater inflater;
    private TreeSet<Integer> set = new TreeSet<Integer>();
    private String ip = "192.168.1.165:8080/bzbp/bzbp/image/1.jpg";

    public FriendAdapter(Context context) throws IOException {
        inflater = LayoutInflater.from(context);
    }

    public void addItem(Friend friend) {
        friends.add(friend);
    }

    public void addSeparatorItem(Friend friend) {
        friends.add(friend);
        set.add(friends.size() - 1);
    }

    public int getItemViewType(int position) {
        return set.contains(position) ? TYPE_SEPARATOR : TYPE_ITEM;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_MAX_COUNT;
    }

    @Override
    public int getCount() {
        return friends.size();
    }

    @Override
    public Object getItem(int position) {
        return friends.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = new ViewHolder();
        if (convertView == null) {
            holder = new ViewHolder();
                    convertView = inflater.inflate(R.layout.adapter_layout, null);
                    holder.textView = (TextView) convertView
                            .findViewById(R.id.item1);
                    holder.imageView = (ImageView) convertView.findViewById(R.id.iv_picture);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.textView.setText(friends.get(position).getNickname());
        byte[] data = new byte[0];
        try {
            data = getBytes(new URL(ip).openStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
        Bitmap bmp = null;
        try {
            bmp = BitmapFactory.decodeByteArray(data,0,data.length);//(ip+"/"+friends.get(position).getUid());
            String TAG = "FriendAdapter";
            Log.d(TAG,"aaaa");
        } catch (Exception e) {
            e.printStackTrace();
        }
        holder.imageView.setImageBitmap(bmp);
        return convertView;
    }

    public static byte[] getBytes(InputStream is) throws IOException {
        ByteArrayOutputStream outstream = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024]; // 用数据装
        int len = -1;
        while ((len = is.read(buffer)) != -1) {
            outstream.write(buffer, 0, len);
        }
        outstream.close();
        return outstream.toByteArray();
    }

    //然后使用方法decodeByteArray（）方法解析编码，生成Bitmap对象。
    public static class ViewHolder {
        public ImageView imageView;
        public TextView textView;
    }
}
