package com.photowalking;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;

import com.photowalking.utils.UrlPath;
import com.photowalking.viewUtils.StatusBarUtil;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 * Created by liujinxu on 17/7/5.
 */

public class WelcomeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        File file = new File(UrlPath.userInfo);
        if(!file.exists()){
                startActivity(new Intent(this,MainActivity.class));
                finish();
        }else{
            try {
                FileInputStream fileInputStream = new FileInputStream(file);
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        fileInputStream, "utf-8"));
                String info = reader.readLine();
                String me = info.split("\\.")[0];
                String uname = info.split("\\.")[1];
                Intent intent = new Intent(this, FragmentsActity.class);
                intent.putExtra("me",me);
                intent.putExtra("uname",uname);
                startActivity(intent);
                finish();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, R.anim.bottom_end);
    }
}