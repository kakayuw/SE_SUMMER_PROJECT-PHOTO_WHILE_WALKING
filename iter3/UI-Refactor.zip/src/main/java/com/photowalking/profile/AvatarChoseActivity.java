package com.photowalking.profile;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.icu.util.Output;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.isseiaoki.simplecropview.CropImageView;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.utils.L;
import com.photowalking.R;
import com.photowalking.fragment.MineFragment;
import com.photowalking.utils.FileUtil;
import com.photowalking.utils.UrlPath;
import com.photowalking.viewUtils.StatusBarUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Created by lionel on 17/8/11.
 */

public class AvatarChoseActivity extends Activity {

    private String type;
    private String me;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        StatusBarUtil.setColor(this, R.color.translucent);

        setContentView(R.layout.profile_avatar_chose);
        final CropImageView imageView = (CropImageView)findViewById(R.id.avatar_chose_img);

        me = getIntent().getStringExtra("me");
        type = getIntent().getStringExtra("type");

        LinearLayout ll_send = (LinearLayout)findViewById(R.id.avatar_chose_send);
        ll_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bmp = imageView.getCroppedBitmap();
                try {
                    final String path = UrlPath.avatarPath+"/"+me+".jpg";
                    OutputStream outputStream = new FileOutputStream(path);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 90, outputStream);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            MineFragment.notifyPhotoUpdate("file://"+path);
                        }
                    });
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                finish();
            }
        });

        String uri = "file://";
        if(type.equals("camera")){
            uri += UrlPath.tmpPic;
        }
        if(type.equals("gallery")){
            uri += FileUtil.getRealPathFromUri( this, getIntent().getData());
        }
        Log.e("Chose File>>>",uri);
        ImageLoader.getInstance().displayImage(uri,imageView);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(type.equals("camera"))
            FileUtil.deleteImage(this, UrlPath.tmpPic);
    }
}
