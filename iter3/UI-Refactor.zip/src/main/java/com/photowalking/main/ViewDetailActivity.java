package com.photowalking.main;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;

import com.baidu.location.LocationClient;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.Polyline;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.map.TextureMapView;
import com.baidu.mapapi.model.LatLng;
import com.github.clans.fab.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.photowalking.R;

import android.widget.AdapterView.OnItemClickListener;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.photowalking.adapter.PhotoAdapter;
import com.photowalking.model.PhotoInfo;
import com.photowalking.model.ShareItem;
import com.photowalking.model.TraceInfo;
import com.photowalking.utils.FileUtil;
import com.photowalking.utils.UrlPath;
import com.photowalking.utils.ZipUtil;
import com.photowalking.viewUtils.HorizontalListView;
import com.photowalking.viewUtils.StatusBarUtil;

import static com.photowalking.R.id.photoNumb;

public class ViewDetailActivity extends Activity {

    private static final String TAG = "ViewDetailActivity";
    private TraceInfo ti = new TraceInfo();
    private PhotoInfo pi = new PhotoInfo();

    private TextureMapView mMapView;
    private BaiduMap mBaiduMap;
    private Polyline mVirtureRoad;
    private Marker mMoveMarker;

    public LocationClient mLocationClient = null;
    private BitmapDescriptor bdA;
    private BitmapDescriptor bdB;

    private OverlayOptions polylineOptions;
    private List<LatLng> polylines = new ArrayList<LatLng>();

    private FileUtil fu = new FileUtil();
    private String uid;
    private String uname;


    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SDKInitializer.initialize(getApplicationContext());
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        StatusBarUtil.setColor(this, R.color.primary);
        setContentView(R.layout.main_show_detail);
        final Intent intent1 = this.getIntent();
        final String date = intent1.getStringExtra("date");
        final String time = intent1.getStringExtra("time");
        uid = intent1.getStringExtra("me");
        uname = intent1.getStringExtra("uname");
        mMapView = (TextureMapView) findViewById(R.id.bmapView);
        mMapView.onCreate(this, savedInstanceState);
        mBaiduMap = mMapView.getMap();

        FloatingActionButton btnShare = (FloatingActionButton)findViewById(R.id.main_detail_fab_share);
        FloatingActionButton btnWechat = (FloatingActionButton)findViewById(R.id.main_detail_fab_wechat);

        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Gson gson = new Gson();
                String traceInfo = gson.toJson(ti);
                Intent intent = new Intent(ViewDetailActivity.this, EditTextActivity.class);
                intent.putExtra("me",uid);
                intent.putExtra("uname",uname);
                intent.putExtra("ti",traceInfo);
                intent.putExtra("date",date);
                intent.putExtra("time",time);
                startActivity(intent);
            }
        });

        btnWechat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO SHARE TRACE AND PICTURE TO WECHAT
                Intent shareIntent = new Intent();
                shareIntent.setAction(Intent.ACTION_SEND);
                ComponentName componentName = new ComponentName("com.tencent.mm","com.tencent.mm.ui.tools.ShareImgUI");
                shareIntent.setComponent(componentName);
//                shareIntent.setPackage("com.tencent.mm");
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, "快来看我分享的路线与照片\n"+
                        UrlPath.wechatShareUrl+"?id="+ti.getTraceId());
//                startActivity(Intent.createChooser(shareIntent, "分享到"));
                startActivity(shareIntent);
            }
        });

        initMarker();
        loadTrace(date,time);
        new LoadPictureTask().execute();
    }

    private void initMarker() {
        bdA = BitmapDescriptorFactory.fromResource(R.drawable.huaji);
        bdB = BitmapDescriptorFactory.fromResource(R.drawable.arrow_down);
        OverlayOptions markerOptions;
        markerOptions = new MarkerOptions().flat(true).anchor(0.5f, 0.5f).icon(bdA).
                position(new LatLng(118.87,42.28)).rotate(0).animateType(MarkerOptions.MarkerAnimateType.drop);
        mMoveMarker = (Marker) mBaiduMap.addOverlay(markerOptions);
    }



    private void loadTrace(String date, String time) {
        polylines = null;           //empty the polylines
        String polyStr = fu.fileToJson(date + "/" + time);
        Gson gson = new Gson();
        List<LatLng> loadPoly = gson.fromJson(polyStr ,new TypeToken<List<LatLng>>() {}.getType());
        polylines = loadPoly;
        polylineOptions = new PolylineOptions().points(polylines).width(6).color(Color.DKGRAY);
        mVirtureRoad = (Polyline) mBaiduMap.addOverlay(polylineOptions);
        String infoStr = fu.fileToJson(date + "/info_" + time);
        ti = gson.fromJson(infoStr, TraceInfo.class);
        if (polylines != null) {
            turnToLocation(polylines.get(0));
        }
    }
    private void turnToLocation(LatLng llA) {
        MapStatus mMapStatus = new MapStatus.Builder()
                .target(llA)
                .zoom(19)
                .build();
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(mMapStatus));
    }

    private class LoadPictureTask extends AsyncTask<Void, Void, List<String>> {
        @Override
        protected List<String> doInBackground(Void... params) {
            List<String> photos = null;
            try {
                photos = getPicturesFromTI();
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return photos;
        }

        @Override
        protected void onPostExecute(List<String> photos) {
            if (photos != null) {
                final PhotoAdapter adapter = new PhotoAdapter(ViewDetailActivity.this);
                for (String s : photos) {
                    adapter.addItem(s);
                }
                HorizontalListView flist = (HorizontalListView) findViewById(R.id.main_detail_photo_list);
                flist.setAdapter(adapter);
                flist.setOnItemClickListener(new OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String photoFileName = adapter.getItem(position);
                        LatLng llA = getPositionFromPI(photoFileName);
                        MarkerOptions ooA = new MarkerOptions().position(llA).icon(bdB).zIndex(9).draggable(true);
                        mBaiduMap.addOverlay(ooA);
                        turnToLocation(llA);
                    }
                });
            }
        }
    }


    private LatLng getPositionFromPI(String photoFile) {
        int len = UrlPath.tracePath.length();
        String date = photoFile.substring(0 + len,10 + len);
        String time = photoFile.substring(11 + len,19 + len);
        File fileList[] = new File(UrlPath.tracePath+date).listFiles();
        for ( int i = 0; i < fileList.length; i++ ) {
            String filename = fileList[i].getName();
            if ( filename.contains("p_") && filename.contains(time) ) {
                Gson gson = new Gson();
                String infoStr = fu.fileToJson(date + "/p_" + time);
                pi = gson.fromJson(infoStr, PhotoInfo.class);
                break;
            }
        }
        LatLng llA = new LatLng(pi.getLat(), pi.getLon());
        return llA;
    }

    private List<String> getPicturesFromTI() throws ParseException {
        List<String> pictureFiles = new ArrayList<String>();
        String path = UrlPath.tracePath + ti.getTraceDate();
        File dateFolder = new File(path);
        File fileList[] = dateFolder.listFiles();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//小写的mm表示的是分钟
        Date start = sdf.parse(ti.getTraceDate() + " " + ti.getStartTime());
        Date end = sdf.parse(ti.getTraceDate() + " " + ti.getEndTime());
        for (int i = 0; i < fileList.length; i++) {
            File filei = fileList[i];

            if (filei.getName().contains(".jpg"))  {
                String timei = filei.getName().substring(0,8);
                Date time = sdf.parse(  ti.getTraceDate() + " " + timei);
                if (time.after(start) && time.before(end)) {
                    pictureFiles.add(UrlPath.tracePath +ti.getTraceDate() + "/" + filei.getName());
                }

            }
        }
        return pictureFiles;
    }

}


