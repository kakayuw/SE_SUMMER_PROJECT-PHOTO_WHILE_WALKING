package com.photowalking.main;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.photowalking.R;
import com.photowalking.model.ShareItem;
import com.photowalking.model.TraceInfo;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;
import com.photowalking.utils.ZipUtil;
import com.photowalking.viewUtils.StatusBarUtil;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.zip.Inflater;

import static android.R.color.transparent;

/**
 * Created by liujinxu on 17/7/18.
 */

public class EditTextActivity extends AppCompatActivity {

    String TAG = "EditTextActivity";

    private TraceInfo ti;
    private String sid;
    private String uid;
    private String uname;
    private String date;
    private String time;
    private int photoNumb;

    private ShareItem si = new ShareItem();

    private String text;
    private String str;
    private String fileUploaded;

    private EditText poem;

    private Dialog dialog;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        StatusBarUtil.setColor(this, R.color.primary);
        setContentView(R.layout.main_share_text);

        Button send = (Button)findViewById(R.id.main_share_send);
        poem = (EditText) findViewById(R.id.main_share_poem);

        Intent intent=getIntent();
        uid = intent.getStringExtra("me");
        uname = intent.getStringExtra("uname");
        String  traceInfo = intent.getStringExtra("ti");
        date = intent.getStringExtra("date");
        time = intent.getStringExtra("time");
//
        Gson gson = new Gson();
        ti = gson.fromJson(traceInfo, TraceInfo.class);
        sid = ti.getTraceId();

        si.setType(1);
        si.setSid(ti.getTraceId());
        si.setTitle(ti.getTraceName());
        String stime = ti.getTraceDate() + " " + ti.getStartTime();
        String etime = ti.getTraceDate() + " " + ti.getEndTime();
        si.setStarttime(stime);
        si.setEndtime(etime);
        si.setUid(Integer.parseInt(uid));
        si.setUsername(uname);
        si.setUpvote(0); //share to all

        poem.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int length = poem.getText().toString().length();
                if(length>=140)
                    Toast.makeText(getApplicationContext(),"字数必须不大于140字",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text = poem.getText().toString();
                showDialog(EditTextActivity.this);
                new Thread(new Runnable(){
                    @Override
                    public void run() {
                        Log.e(TAG, "compress started >>> ");
                        compressTrace(date , time);
                        Log.e(TAG, "compress ended<<<<");
                        OkManager okManager = new OkManager();
                        si.setPoem(text);
                        si.setPicnum(photoNumb);
                        Gson g = new Gson();
                        String siStr = g.toJson(si);
                        str = okManager.sendStringByPost(UrlPath.uploadSitemUrl,siStr);
                        if(str.equals("success")){
                        File file = new File(UrlPath.uploadTmpPath+"/"+sid+".zip");
                            Log.e(">>>>>>>>>>","upload started.....");
                            fileUploaded = okManager.uploadFile(UrlPath.uploadUrl+sid, file);
                            Log.e("<<<<<<<<<<","upload ended.....");
                            file.delete();
                        }
                        if(fileUploaded.equals("success")){
                            str = "上传成功";
                        }else{
                            str = "上传失败";
//                            okManager.deleteStringByGet(UrlPath.deleteSitemUrl);
                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                dismissDialog();
                                Toast.makeText(getApplicationContext(),str,Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        });
                    }
                }).start();
            }
        });

    }

    private void compressTrace(String date, String time) {
        List<String> files = new ArrayList<>();
        files.add(UrlPath.tracePath + date + "/" + time);
        files.add(UrlPath.tracePath + date + "/info_" + time);
        List<String> photos = null;
        List<String> infos = null;
        try {
            photos = getPicturesFromTI();
            infos = getPicturesInfoFromTI();
            photoNumb = photos.size();
            for (int i = 0; i < photoNumb; i++) {
                files.add(photos.get(i));
            }
            for (int i = 0; i < infos.size(); i++) {
                files.add(infos.get(i));
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        for ( int i = 0 ; i < files.size(); i++) {
            Log.e("fff:",files.get(i));
        }
        ZipUtil.compress(sid, files);
    }

    private List<String> getPicturesFromTI() throws ParseException {
        List<String> pictureFiles = new ArrayList<>();
        String path = UrlPath.tracePath + ti.getTraceDate();
        File dateFolder = new File(path);
        File fileList[] = dateFolder.listFiles();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//小写的mm表示的是分钟
        Date start = sdf.parse(ti.getTraceDate() + " " + ti.getStartTime());
        Date end = sdf.parse(ti.getTraceDate() + " " + ti.getEndTime());
        for (int i = 0; i < fileList.length; i++) {
            File filei = fileList[i];

            if (filei.getName().contains(".jpg"))  {
                String timei = filei.getName().substring(0,8);
                Date time = sdf.parse(  ti.getTraceDate() + " " + timei);
                if (time.after(start) && time.before(end)) {
                    pictureFiles.add(UrlPath.tracePath +ti.getTraceDate() + "/" + filei.getName());
                }

            }
        }
        return pictureFiles;
    }

    private List<String> getPicturesInfoFromTI() throws ParseException {
        List<String> pictureInfoFiles = new ArrayList<String>();
        String path = UrlPath.tracePath + ti.getTraceDate();
        File dateFolder = new File(path);
        File fileList[] = dateFolder.listFiles();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//小写的mm表示的是分钟
        Date start = sdf.parse(ti.getTraceDate() + " " + ti.getStartTime());
        Date end = sdf.parse(ti.getTraceDate() + " " + ti.getEndTime());
        for (int i = 0; i < fileList.length; i++) {
            File filei = fileList[i];
            if (filei.getName().contains("p_")) {
                String timei = filei.getName().substring(2,10);
                Date time = sdf.parse(  ti.getTraceDate() + " " + timei);
                if (time.after(start) && time.before(end)) {
                    pictureInfoFiles.add(UrlPath.tracePath +ti.getTraceDate() + "/" + filei.getName());
                }
            }
        }
        return pictureInfoFiles;
    }

    public void showDialog(Context context){
        dialog = new Dialog(context);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.main_share_loading);
        dialog.show();
    }

    public void dismissDialog(){
        if(dialog!=null)
            dialog.dismiss();
    }
}