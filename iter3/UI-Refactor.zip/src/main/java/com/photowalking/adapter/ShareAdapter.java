package com.photowalking.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.photowalking.R;
import com.photowalking.model.ShareItem;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by lionel on 2017/7/7.
 */

public class ShareAdapter extends BaseAdapter {

    private ArrayList<ShareItem> shares = new ArrayList<ShareItem>();
    private LayoutInflater inflater;
    private String ip;
    private int layout;
    private ViewHolder holder;

    public ShareAdapter(Context context, String ip, int layout) {
        inflater = LayoutInflater.from(context);
        this.ip = ip;
        this.layout = layout;

    }

    public void addItem(ShareItem shareItem){
        shares.add(shareItem);
    }

    @Override
    public int getCount() {
        return shares.size();
    }

    @Override
    public ShareItem getItem(int position) {
        return shares.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public void clear(){
        shares.clear();
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(layout, null);
            holder.uname = (TextView) convertView.findViewById(R.id.share_item_uname);
            holder.textView = (TextView) convertView.findViewById(R.id.share_item_text);
            holder.imageView = (ImageView) convertView.findViewById(R.id.share_item_picture);
            holder.begin = (TextView) convertView.findViewById(R.id.share_main_item_stime);
            holder.end = (TextView) convertView.findViewById(R.id.share_main_item_tottime);
            holder.miles = (TextView) convertView.findViewById(R.id.share_main_item_miles);
            holder.photos = (TextView) convertView.findViewById(R.id.share_main_item_photos);
            holder.poem = (TextView) convertView.findViewById(R.id.share_item_poem);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.uname.setText(shares.get(position).getUsername());
        holder.textView.setText(shares.get(position).getTitle());
        holder.begin.setText(shares.get(position).getStarttime());
        holder.end.setText(shares.get(position).getEndtime());
        holder.miles.setText("1");//TODO : the miles of the trace has not been added into the shareItem yet
        holder.poem.setText(shares.get(position).getPoem());
        holder.photos.setText(String.valueOf(shares.get(position).getPicnum()));

        new SetImageTask().execute(new ImageHolder(ip+shares.get(position).getUid(), holder.imageView));
        return convertView;
    }

    public static class ViewHolder {
        public ImageView imageView;
        public TextView uname;
        public TextView textView;
        public TextView begin;
        public TextView end;
        public TextView miles;
        public TextView photos;
        public TextView poem;
    }
}
