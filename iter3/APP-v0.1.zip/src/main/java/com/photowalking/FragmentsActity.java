package com.photowalking;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.baidu.platform.comapi.map.F;
import com.photowalking.fragment.FriendFragment;
import com.photowalking.fragment.MainFragment;
import com.photowalking.fragment.MineFragment;
import com.photowalking.fragment.ShareFragment;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;
import com.photowalking.viewUtils.StatusBarUtil;

import java.io.File;

import cn.jpush.android.api.JPushInterface;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;

/**
 * Created by lionel on 2017/7/10.
 */

public class FragmentsActity extends Activity implements View.OnClickListener {

    /* Four LinearLayout at bottom */
    private LinearLayout mainTab;
    private LinearLayout friendTab;
    private LinearLayout shareTab;
    private LinearLayout mineTab;

    /* Four ImageButtons at bottom */
    private ImageView mainTabImg;
    private ImageView friendTabImg;
    private ImageView shareTabImg;
    private ImageView mineTabImg;

    /* Four Framgments at center */
    private MainFragment mainFragment;
    private FriendFragment friendFragment;
    private ShareFragment shareFragment;
    private MineFragment mineFragment;

    private static String uid;
    private static String uname;
    private static boolean friFragOpend = false;

    private int idx;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        StatusBarUtil.setTransparent(this);
        setContentView(R.layout.tabs_layout);

        init();
        uid = getIntent().getStringExtra("me");
        uname = getIntent().getStringExtra("uname");
        showFragment(0);
    }

    public static boolean isfriFragOpend(){
        return friFragOpend;
    }

    private void init(){
        mainTab = (LinearLayout) findViewById(R.id.main_tab);
        friendTab = (LinearLayout) findViewById(R.id.friend_tab);
        shareTab = (LinearLayout) findViewById(R.id.share_tab);
        mineTab = (LinearLayout) findViewById(R.id.mine_tab);

        mainTabImg = (ImageView) findViewById(R.id.main_tab_img);
        friendTabImg = (ImageView)findViewById(R.id.friend_tab_img);
        shareTabImg = (ImageView) findViewById(R.id.share_tab_img);
        mineTabImg = (ImageView) findViewById(R.id.mine_tab_img);

        mainTab.setOnClickListener(this);
        friendTab.setOnClickListener(this);
        shareTab.setOnClickListener(this);
        mineTab.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.main_tab:
                showFragment(0);
                break;
            case R.id.friend_tab:
                showFragment(1);
                break;
            case R.id.share_tab:
                showFragment(2);
                break;
            case R.id.mine_tab:
                showFragment(3);
                break;
            default: break;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putInt("idx", idx);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        showFragment(savedInstanceState.getInt("idx"));
        super.onRestoreInstanceState(savedInstanceState);
    }

    private void showFragment(int index){
        FragmentManager fm = getFragmentManager();
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
        hideFragment(fragmentTransaction);
        resetImg();
        idx = index;
        switch (index){
            case 0:
                if (mainFragment == null){
                    mainFragment = MainFragment.getInstance(uid, uname);
                    fragmentTransaction.add(R.id.tab_content,mainFragment);
                }else{
                    fragmentTransaction.show(mainFragment);

                }
                fragmentTransaction.commit();
                mainTabImg.setImageResource(R.drawable.homepage2);

                break;
            case 1:
                if (friendFragment==null){
                    friendFragment = FriendFragment.getInstace(uid);
                    fragmentTransaction.add(R.id.tab_content,friendFragment);
                    friFragOpend = true;
                }else{
                    fragmentTransaction.show(friendFragment);
                }

                fragmentTransaction.commit();
                friendTabImg.setImageResource(R.drawable.friends2);


                break;
            case 2:
                if (shareFragment==null){
                    shareFragment = ShareFragment.getInstance(uid, uname);
                    fragmentTransaction.add(R.id.tab_content,shareFragment);
                }else{
                    fragmentTransaction.show(shareFragment);
                }
                fragmentTransaction.commit();
                shareTabImg.setImageResource(R.drawable.sharedcircle2);
                break;
            case 3:
                if (mineFragment==null){
                    mineFragment = MineFragment.getInstance(uid);
                    fragmentTransaction.add(R.id.tab_content,mineFragment);
                }else{
                    fragmentTransaction.show(mineFragment);
                }
                fragmentTransaction.commit();
                mineTabImg.setImageResource(R.drawable.me2);
                break;
            default: break;
        }
    }

    private void hideFragment(FragmentTransaction fragmentTransaction) {
        if (mainFragment!=null){
            fragmentTransaction.hide(mainFragment);
        }
        if (friendFragment!=null){
            fragmentTransaction.hide(friendFragment);
        }
        if (shareFragment!=null){
            fragmentTransaction.hide(shareFragment);
        }
        if (mineFragment!=null){
            fragmentTransaction.hide(mineFragment);
        }
    }

    private void resetImg() {
        mainTabImg.setImageResource(R.drawable.homepage);
        friendTabImg.setImageResource(R.drawable.friends);
        shareTabImg.setImageResource(R.drawable.sharedcircle);
        mineTabImg.setImageResource(R.drawable.me);
    }

    @Override
    protected void onDestroy() {
        //TODO DELETE FOLDERS & FILES
        File parent = new File(UrlPath.downloadPath);
        if(parent.exists()){
            File[] folders = parent.listFiles();
            if(folders.length > 0){
                for(int i=0; i< folders.length; ++i){
                    File folder = folders[i];
                    File[] files = folder.listFiles();
                    if(files.length>0){
                        for(int j=0; j<files.length; ++j){
                            files[i].delete();
                    }
                    folder.delete();
                }
    //            for(File folder:folders){
    //                File[] files = folder.listFiles();
    //                if(files.length>0){
    //                    for(File file : files)
    //                        file.delete();
    //                }
    //                folder.delete();
                }
            }
        }
        super.onDestroy();
    }
}
