package com.photowalking.share;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.baidu.location.LocationClient;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.Polyline;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.map.TextureMapView;
import com.baidu.mapapi.model.LatLng;
import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.FloatingActionMenu;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.photowalking.R;
import com.photowalking.adapter.PhotoAdapter;
import com.photowalking.model.PhotoInfo;
import com.photowalking.model.TraceInfo;
import com.photowalking.utils.FileUtil;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;
import com.photowalking.utils.ZipUtil;
import com.photowalking.viewUtils.HorizontalListView;
import com.photowalking.viewUtils.StatusBarUtil;

import java.io.File;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

public class ViewOthersDetailActivity extends AppCompatActivity {

    private static final String TAG = "viewOthersDetailActivity";
    private TraceInfo ti = new TraceInfo();
    private PhotoInfo pi = new PhotoInfo();

    private TextureMapView mMapView;
    private BaiduMap mBaiduMap;
    private Polyline mVirtureRoad;
    private Marker mMoveMarker;
    public LocationClient mLocationClient = null;
    private BitmapDescriptor bdA;
    private BitmapDescriptor bdB;

    private OverlayOptions polylineOptions;
    private List<LatLng> polylines = new ArrayList<LatLng>();

    private FileUtil fu = new FileUtil();

    List<String> photos = new ArrayList<String>();
    List<String> infos = new ArrayList<String>();

    private String uid;
    private String sid;

    private OkManager okManager = new OkManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SDKInitializer.initialize(getApplicationContext());
        StatusBarUtil.setColor(this, R.color.primary);
        setContentView(R.layout.share_show_detail);
        ButterKnife.bind(this);
        Intent intent1 = this.getIntent();
        uid = intent1.getStringExtra("me");
        sid = intent1.getStringExtra("sid");

        mMapView = (TextureMapView) findViewById(R.id.share_bmapView);
        mMapView.onCreate(this, savedInstanceState);
        mBaiduMap = mMapView.getMap();

        new Thread(new Runnable() {
            @Override
            public void run() {
                String filepath = UrlPath.downloadPath+"/"+sid+".zip";
                File folder = new File(UrlPath.downloadPath+"/"+sid);
                if(!folder.exists() || folder.listFiles().length == 0) {
                    OkManager okManager = new OkManager();
                    Log.e(">>>>>>>", "download started...");
                    if(okManager.downloadFile(UrlPath.downloadUrl + sid, filepath)=="success"){
                        Log.e(">>>>>>>", "download ended...");
                        File file = new File(filepath);
                        Log.e(">>>>>>>", "decompress started...");
                        if(ZipUtil.decompress(file)==true){
                            Log.e(">>>>>>>", "decompress ended...");
                            file.delete();
                        }
                    }else{
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(),"获取失败",Toast.LENGTH_SHORT);
                            }
                        });
                    }
                }
                initPaths(sid);
                initMarker();
                loadTrace();
                new LoadPictureTask().execute();
            }
        }).start();
    }

    private void initPaths(String traceid) {
        String traceidPath = UrlPath.downloadPath + "/" + traceid;
        File fileList[] = new File(traceidPath).listFiles();
        for ( int i = 0; i < fileList.length; i++ ) {
            String filename = fileList[i].getName();
            if (filename.contains(".jpg")) {
                photos.add(traceidPath + "/" + filename);
            } else if (filename.contains("p_")) {
                infos.add(traceidPath + "/" + filename);
            } else if (filename.contains("info_")) {
                ti.setInfoFileName(traceidPath + "/" + filename);
            } else {
                ti.setFileName(traceidPath + "/" + filename);
            }
        }
    }

    private void initMarker() {
        bdA = BitmapDescriptorFactory.fromResource(R.drawable.huaji);
        bdB = BitmapDescriptorFactory.fromResource(R.drawable.arrow_down);
        OverlayOptions markerOptions;
        markerOptions = new MarkerOptions().flat(true).anchor(0.5f, 0.5f).icon(bdA).
                position(new LatLng(118.87,42.28)).rotate(0).animateType(MarkerOptions.MarkerAnimateType.drop);
        mMoveMarker = (Marker) mBaiduMap.addOverlay(markerOptions);
    }

    private void loadTrace() {
        polylines = null;           //empty the polylines
        String polyStr = fu.AfileToJson(ti.getFileName());
        Gson gson = new Gson();
        List<LatLng> loadPoly = gson.fromJson(polyStr ,new TypeToken<List<LatLng>>() {}.getType());
        polylines = loadPoly;
        polylineOptions = new PolylineOptions().points(polylines).width(6).color(Color.GREEN);
        mVirtureRoad = (Polyline) mBaiduMap.addOverlay(polylineOptions);
        String infoStr = fu.AfileToJson(ti.getInfoFileName());
        ti = gson.fromJson(infoStr, TraceInfo.class);
        if (polylines != null) {
            turnToLocation(polylines.get(0));
        }
    }
    private void turnToLocation(LatLng llA) {
        MapStatus mMapStatus = new MapStatus.Builder()
                .target(llA)
                .zoom(21)
                .build();
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newMapStatus(mMapStatus));
    }

    private class LoadPictureTask extends AsyncTask<Void, Void, List<String>> {
        @Override
        protected List<String> doInBackground(Void... params) {
            List<String> photos = null;
            try {
                photos = getPicturesFromTI();
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return photos;
        }

        @Override
        protected void onPostExecute(List<String> photos) {
            if (photos != null) {
                final PhotoAdapter adapter = new PhotoAdapter(ViewOthersDetailActivity.this);
                for (String s : photos) {
                    adapter.addItem(s);
                }
                HorizontalListView flist = (HorizontalListView) findViewById(R.id.share_detail_photo_list);
                flist.setAdapter(adapter);
                flist.setOnItemClickListener(new OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String photoFileName = adapter.getItem(position);
                        LatLng llA = getPositionFromPI(photoFileName);
                       /* mMoveMarker.setPosition(llA);*/
                        turnToLocation(llA);

                        mMoveMarker.remove();
                        OverlayOptions markerOptions = new MarkerOptions().flat(true).anchor(0.5f, 0.5f).icon(bdA).
                                position(llA).rotate(0).animateType(MarkerOptions.MarkerAnimateType.grow);
                        mMoveMarker = (Marker) mBaiduMap.addOverlay(markerOptions);
                    }
                });
            }
        }
    }

    private LatLng getPositionFromPI(String photoFile) {
        String time = photoFile.substring(photoFile.lastIndexOf("/") + 1).substring(0,8);
        File fileList[] = new File(UrlPath.downloadPath + "/" + ti.getTraceId()).listFiles();
        Log.e("timeInPI",time);
        for ( int i = 0; i < fileList.length; i++ ) {
            String filename = fileList[i].getName();
            if ( filename.contains("p_") && filename.contains(time) ) {
                Gson gson = new Gson();
                String infoStr = fu.AfileToJson(UrlPath.downloadPath + "/" + ti.getTraceId() + "/" + filename);
                pi = gson.fromJson(infoStr, PhotoInfo.class);
                break;
            }
        }
        LatLng llA = new LatLng(pi.getLat(), pi.getLon());
        return llA;
    }

    private List<String> getPicturesFromTI() throws ParseException {
        return photos;
    }
}


