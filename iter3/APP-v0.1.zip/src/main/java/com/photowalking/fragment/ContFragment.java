package com.photowalking.fragment;

import android.app.Fragment;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.photowalking.R;

import java.util.List;

import com.photowalking.adapter.ShareAdapter;
import com.photowalking.listener.ShareRefreshListener;
import com.photowalking.model.ShareItem;
import com.photowalking.share.AllCommentActivity;
import com.photowalking.share.ShareHolder;
import com.photowalking.share.ViewOthersDetailActivity;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;
import com.photowalking.viewUtils.PullableRelativeLayout;

/**
 * Created by lionel on 2017/7/10.
 */

public class ContFragment extends Fragment{

    private View view;


    private PullableRelativeLayout prl;
    private ListView listView;

    private String uid;
    private String uname;

    public static ContFragment getInstance(int res, String uid, String uname){
        ContFragment fragment = new ContFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("res", res);
        bundle.putString("me",uid);
        bundle.putString("uname",uname);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        int res = getArguments().getInt("res");
        view = inflater.inflate(res, container, false);
        uid = getArguments().getString("me");
        uname = getArguments().getString("uname");
        switch(res){
            case R.layout.share_fri:
                listView = (ListView) view.findViewById(R.id.fri_share_list);
                ShareHolder shareFHolder = new ShareHolder(getActivity(),listView,UrlPath.getShareFriUrl+uid,uid,uname);
//                new LoadShareTask().execute(shareFHolder);
                prl = (PullableRelativeLayout)view.findViewById(R.id.fri_share_pullable_layout);
                prl.setOnRefreshListener(new ShareRefreshListener(getActivity(),shareFHolder));
                prl.autoRefresh();
                break;
            case R.layout.share_all:
                listView = (ListView) view.findViewById(R.id.all_share_list);
                ShareHolder shareAHolder = new ShareHolder(getActivity(),listView,UrlPath.getShareAllUrl+uid,uid,uname);
//                new LoadShareTask().execute(shareAHolder);
                prl = (PullableRelativeLayout)view.findViewById(R.id.all_share_pullable_layout);
                prl.setOnRefreshListener(new ShareRefreshListener(getActivity(),shareAHolder));
                prl.autoRefresh();
                break;
            case R.layout.share_mine:
                listView = (ListView) view.findViewById(R.id.my_share_list);
                ShareHolder shareMHolder = new ShareHolder(getActivity(),listView,UrlPath.getShareMineUrl+uid,uid,uname);
//                new LoadShareTask().execute(shareMHolder);
                prl = (PullableRelativeLayout)view.findViewById(R.id.my_share_pullable_layout);
                prl.setOnRefreshListener(new ShareRefreshListener(getActivity(),shareMHolder));
                prl.autoRefresh();
                break;
            default: break;
        }
        return view;
    }

//    public class LoadShareTask extends AsyncTask<ShareHolder, Void, List<ShareItem>> {
//
//        private ShareHolder shareHolder;
//        private ShareAdapter shareAdapter;
//
//        @Override
//        protected List<ShareItem> doInBackground(ShareHolder... params) {
//            if (params.length == 0) {
//                return null;
//            }
//            shareHolder = params[0];
//            String url = params[0].url;
//            if(!OkManager.checkNetwork(ContFragment.this.getActivity().getApplicationContext())){
//                handler.post(new Runnable() {
//                    @Override
//                    public void run() {
//                        Toast.makeText(getActivity().getApplicationContext(),"未连接到网络",Toast.LENGTH_SHORT).show();
//                    }
//                });
//                return null;
//            }
//            OkManager manager = new OkManager<>();
//            List<ShareItem> shares= manager.getAll(url+"/"+shareHolder.pagenum, ShareItem.class);
//            return shares;
//        }
//
//        @Override
//        protected void onPostExecute(List<ShareItem> shareItems) {
//            if(shareItems==null){
//                prl.refreshFinish(PullableRelativeLayout.FAIL);
//                return;
//            }
//            shareAdapter = (ShareAdapter) shareHolder.listView.getAdapter();
//            if(shareAdapter == null){
//                shareAdapter = new ShareAdapter(shareHolder.context, UrlPath.getPicUrl,
//                        R.layout.shareitem_layout);
//                shareHolder.listView.setAdapter(shareAdapter);
//            }
//            shareAdapter.clear();
//            for(ShareItem s : shareItems){
//                shareAdapter.addItem(s);
//            }
//            shareAdapter.notifyDataSetChanged();
//            shareHolder.listView.setAdapter(shareAdapter);
//            shareHolder.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                @Override
//                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                    String sid = shareAdapter.getItem(position).getSid();
//                    Intent intent = new Intent(shareHolder.context, ViewOthersDetailActivity.class);
//                    intent.putExtra("sid",sid);
//                    intent.putExtra("me",shareHolder.uid);
//                    shareHolder.context.startActivity(intent);
//                }
//            });
//        }
//    }
}
