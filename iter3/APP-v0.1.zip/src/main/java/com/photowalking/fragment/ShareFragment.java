package com.photowalking.fragment;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.photowalking.R;
import com.photowalking.share.ShareHolder;
import com.photowalking.viewUtils.StatusBarUtil;

/**
 * Created by lionel on 2017/7/11.
 */

public class ShareFragment extends Fragment implements View.OnClickListener {

    /* Three LinearLayouts at top */
    private LinearLayout friTab;
    private LinearLayout allTab;
    private LinearLayout myTab;

    /* Three ImageViews & TextViews at top */
    private ImageView friImg;
    private ImageView allImg;
    private ImageView myImg;

    private TextView friText;
    private TextView allText;
    private TextView myText;

    /* Three Framgments at center */
    private ContFragment friFragment;
    private ContFragment allFragment;
    private ContFragment myFragment;

    private static View shareView;


    private String uid;
    private String uname;

    public static ShareFragment getInstance(String uid, String uname){
        ShareFragment shareFragment = new ShareFragment();
        Bundle bundle = new Bundle();
        bundle.putString("me",uid);
        bundle.putString("uname",uname);
        shareFragment.setArguments(bundle);
        return  shareFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        shareView = inflater.inflate(R.layout.tab_share, container, false);
        uid = getArguments().getString("me");
        uname = getArguments().getString("uname");
        init();
        setSelect(0);
        return shareView;
    }


    private void init(){
        friImg = (ImageView)shareView.findViewById(R.id.fri_share_tab_img);
        allImg = (ImageView)shareView.findViewById(R.id.all_share_tab_img);
        myImg = (ImageView)shareView.findViewById(R.id.my_share_tab_img);

        friText = (TextView) shareView.findViewById(R.id.fri_share_tab_tv);
        allText = (TextView)shareView.findViewById(R.id.all_share_tab_tv);
        myText = (TextView)shareView.findViewById(R.id.my_share_tab_tv);


        friTab = (LinearLayout)shareView.findViewById(R.id.fri_share_tab);
        allTab = (LinearLayout)shareView.findViewById(R.id.all_share_tab);
        myTab = (LinearLayout)shareView.findViewById(R.id.my_share_tab);

        friTab.setOnClickListener(this);
        allTab.setOnClickListener(this);
        myTab.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        resetImgBtn();
        switch (v.getId()) {
            case R.id.fri_share_tab:
                setSelect(0);
                break;
            case R.id.all_share_tab:
                setSelect(1);
                break;
            case R.id.my_share_tab:
                setSelect(2);
                break;
            default:
                break;
        }
    }

    private void setSelect(int index){
        FragmentManager fm = getChildFragmentManager();
        FragmentTransaction fragmentTransaction = fm.beginTransaction();
        resetImgBtn();
        hideFragment(fragmentTransaction);
        switch (index){
            case 0:
                friImg.setImageResource(R.drawable.friendshare2);
                friText.setTextColor(0xffd81e06);
                if (friFragment == null){
                    friFragment = ContFragment.getInstance(R.layout.share_fri, uid, uname);
                    fragmentTransaction.add(R.id.share_list_view,friFragment);
                }else {
                    fragmentTransaction.show(friFragment);
                }
                fragmentTransaction.commit();
                break;
            case 1:
                allImg.setImageResource(R.drawable.allpeople2);
                allText.setTextColor(0xffd81e06);
                if (allFragment == null){
                    allFragment = ContFragment.getInstance(R.layout.share_all, uid, uname);
                    fragmentTransaction.add(R.id.share_list_view,allFragment);
                }else{
                    fragmentTransaction.show(allFragment);
                }
                fragmentTransaction.commit();
                break;
            case 2:
                myImg.setImageResource(R.drawable.my2);
                myText.setTextColor(0xffd81e06);
                if (myFragment == null){
                    myFragment = ContFragment.getInstance(R.layout.share_mine, uid, uname);
                    fragmentTransaction.add(R.id.share_list_view,myFragment);
                }else{
                    fragmentTransaction.show(myFragment);
                }
                fragmentTransaction.commit();
                break;
            default: break;
        }
    }

    private void hideFragment(FragmentTransaction fragmentTransaction) {
        if (friFragment!=null){
            fragmentTransaction.hide(friFragment);
        }
        if (allFragment!=null){
            fragmentTransaction.hide(allFragment);
        }
        if (myFragment!=null){
            fragmentTransaction.hide(myFragment);
        }
    }

    private void resetImgBtn() {
        friImg.setImageResource(R.drawable.friendshare);
        allImg.setImageResource(R.drawable.allpeople);
        myImg.setImageResource(R.drawable.my);

        friText.setTextColor(0xff8a8a8a);
        allText.setTextColor(0xff8a8a8a);
        myText.setTextColor(0xff8a8a8a);
    }


}
