package action;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;

import com.mysql.jdbc.ReflectiveStatementInterceptorAdapter;
import com.sun.org.apache.bcel.internal.generic.ReturnaddressType;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.struts2.ServletActionContext;

import dao.ProfileDao;
import dao.UserDao;
import model.Comment;
import model.Contacter;
import model.User;
import net.sf.json.JSONArray;
import service.UserService;
import service.UserpicService;
import service.CommentService;
import service.ContacterService;
import service.RouteService;

public class ShareAction extends BaseAction{
	
	private RouteService routeService;
	private CommentService commentService;
	private String sid;
	
	public RouteService getRouteService() {
		return routeService;
	}

	public void setRouteService(RouteService routeService) {
		this.routeService = routeService;
	}

	public CommentService getCommentService() {
		return commentService;
	}

	public void setCommentService(CommentService commentService) {
		this.commentService = commentService;
	}
	

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}
	
	
	//method	
	public void getRoute() throws IOException {
		String id = request().getParameter("id");
		String route = routeService.getShareRoute(id);
		HttpServletResponse response = ServletActionContext.getResponse();
		response.getWriter().write(route);
	}
	
	public void getComment(){
		
		List<Comment> result = commentService.getCommentBySid(sid);
		try {
			JSONArray jsonArray = JSONArray.fromObject(result);
			response().setCharacterEncoding("utf-8");
			response().getWriter().println(jsonArray);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}


	
}
