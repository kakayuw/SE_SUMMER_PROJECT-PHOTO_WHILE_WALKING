package com.photowalking.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.baidu.platform.comapi.map.F;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.photowalking.FragmentsActity;
import com.photowalking.LoginActivity;
import com.photowalking.MainActivity;
import com.photowalking.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import com.photowalking.SignupActivity;
import com.photowalking.profile.ProfileAboutActivity;
import com.photowalking.profile.ProfileAvatarActivity;
import com.photowalking.profile.ProfileChargeActivity;
import com.photowalking.profile.ProfileEditActivity;
import com.photowalking.profile.ProfilePhoneActivity;
import com.photowalking.profile.ProfilePwdActivity;
import com.photowalking.utils.FileUtil;
import com.photowalking.utils.OkManager;
import com.photowalking.utils.UrlPath;
import com.photowalking.viewUtils.UserInfoSharedPreference;

import cn.jpush.android.api.JPushInterface;

/**
 * Created by lionel on 2017/7/11.
 */

public class MineFragment extends Fragment{
    private View view;
    private static ImageView photo;

    LinearLayout about_layout;
    LinearLayout edit_layout;
    LinearLayout phone_layout;
    LinearLayout charge_layout;
    LinearLayout logout_layout;
    LinearLayout pwd_layout;

    private String uid;

    private boolean flag = true;

    public static MineFragment getInstance(String uid){
        MineFragment mineFragment = new MineFragment();
        Bundle bundle = new Bundle();
        bundle.putString("me",uid);
        mineFragment.setArguments(bundle);
        return mineFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.tab_me, container, false);

        uid = getArguments().getString("me");
        init();
        return view;
    }

    public void init() {
        photo = (ImageView) view.findViewById(R.id.photo);
        new ShowPhotoTask().execute(uid);

        about_layout = (LinearLayout) view.findViewById(R.id.tab_me_about_bzbp);
        edit_layout = (LinearLayout) view.findViewById(R.id.tab_me_edit_info);
        phone_layout = (LinearLayout) view.findViewById(R.id.tab_me_modify_phone);
        charge_layout = (LinearLayout) view.findViewById(R.id.tab_me_charge);
        logout_layout = (LinearLayout) view.findViewById(R.id.tab_me_logout);
        pwd_layout = (LinearLayout) view.findViewById(R.id.tab_me_modify_pwd);

        photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(flag==true){
                    Intent intent = new Intent(getActivity(), ProfileAvatarActivity.class);
                    intent.putExtra("me",uid);
                    startActivityForResult(intent, 1);
                }else{
                    photo.setImageBitmap(null);
                    new ShowPhotoTask().execute(uid);
                }
            }
        });

        about_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ProfileAboutActivity.class);
                intent.putExtra("me",uid);
                startActivityForResult(intent, 1);
            }
        });

        charge_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ProfileChargeActivity.class);
                intent.putExtra("me",uid);
                startActivityForResult(intent, 1);
            }
        });

        pwd_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ProfilePwdActivity.class);
                intent.putExtra("me",uid);
                startActivityForResult(intent, 1);
            }
        });

        edit_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),  ProfileEditActivity.class);
                intent.putExtra("me",uid);
                startActivityForResult(intent, 1);

            }
        });

        phone_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),  ProfilePhoneActivity.class);
                intent.putExtra("me",uid);
                startActivityForResult(intent, 1);
            }
        });

        logout_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MineFragment.this.getActivity(), R.style.AppTheme_Light_Dialog)
                        .setMessage("确定退出当前账号吗？")
                        .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                JPushInterface.deleteAlias(MineFragment.this.getActivity(),1);
                                UserInfoSharedPreference.delete(MineFragment.this.getActivity());
                                Intent intent = new Intent(getActivity(), MainActivity.class);
                                startActivity(intent);
                                MineFragment.this.getActivity().finish();
                            }
                        }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
            }
        });
    }

    public static void notifyPhotoUpdate(String uri){
        ImageLoader.getInstance().displayImage(uri, photo);
    }

    private class ShowPhotoTask extends AsyncTask<String, Void, String>{

        @Override
        protected String doInBackground(String... params) {
            if(params.length == 0)
                return null;
            File parent = new File(UrlPath.APP_PATH);
            if(!parent.exists())
                parent.mkdir();
            File folder = new File(UrlPath.avatarPath);
            if(!folder.exists())
                folder.mkdir();
            String path = UrlPath.avatarPath+"/"+uid+".jpg";
            File pic = new File(path);
            if(!pic.exists()){
                try {
                    OkManager okManager = new OkManager();
                    if(!okManager.downloadFile(UrlPath.getPicUrl+params[0],path).equals("success")){
                        return null;
                    };
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return "file://"+path;
        }

        @Override
        protected void onPostExecute(String uri) {
            if(uri==null){
                photo.setImageResource(R.drawable.avatar_fail);
                flag = false;
                return;
            }
            flag = true;
            ImageLoader.getInstance().displayImage(uri, photo);
        }
    }
}
