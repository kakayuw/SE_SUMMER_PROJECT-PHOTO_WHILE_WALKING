package com.photowalking;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;

import com.photowalking.share.AllCommentActivity;
import com.photowalking.utils.UrlPath;
import com.photowalking.viewUtils.StatusBarUtil;
import com.photowalking.viewUtils.UserInfoSharedPreference;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import cn.jpush.android.api.JPushInterface;

/**
 * Created by liujinxu on 17/7/5.
 */

public class WelcomeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            Thread.sleep(1200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String uid = UserInfoSharedPreference.getUid(this);
        String uname = UserInfoSharedPreference.getUname(this);
        if(uid == null || uname == null){
                startActivity(new Intent(this,MainActivity.class));
                finish();
        }else{
            JPushInterface.resumePush(this);
            Intent intent = new Intent(this, FragmentsActity.class);
            intent.putExtra("me",uid);
            intent.putExtra("uname",uname);
            startActivity(intent);
            finish();
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, R.anim.bottom_end);
    }
}